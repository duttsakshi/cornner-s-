/**
 * Conners 3 Parent Short - Instrument configuration JS export
 */
export * from './connersConfig.ts';
