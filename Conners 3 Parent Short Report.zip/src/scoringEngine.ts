/**
 * Deterministic Scoring Engine for Conners 3 Parent Short
 *
 * NON-NEGOTIABLE RULE 1:
 * All scoring is deterministic JavaScript using tables. No AI is used for any calculations.
 */

import {
  ITEMS,
  CONTENT_SCALES,
  VALIDITY_SCALES,
  SCALE_CODES,
  ScaleCode,
  ValidityCode,
  AnyScaleCode,
  NormTableData,
  AllNormTables,
  Sex,
  calculateApproxPercentile,
  getDescriptiveBand,
  VALIDITY_MESSAGES,
  ValidityLevel,
  getNormGroupKey,
  formatNormGroupDisplay,
} from './connersConfig';

export interface ScoreReportScale {
  code: ScaleCode;
  name: string;
  description: string;
  rawScore: number;
  maxRaw: number;
  tScore: number | null;
  tScoreDisplay: string;
  percentile: number | null;
  bandWording: string | null;
  hasNorms: boolean;
}

export interface ScoreReportValidity {
  piRaw: number;
  niRaw: number;
  piLevel: ValidityLevel;
  niLevel: ValidityLevel;
  overallLevel: ValidityLevel;
  title: string;
  body: string;
  subtext: string;
}

export interface AreaToExplore {
  scaleCode: ScaleCode;
  scaleName: string;
  description: string;
  tScore: number;
  percentile: number;
  bandWording: string;
  narrative: string;
}

export interface ScoredAssessmentReport {
  childId: string;
  childName?: string;
  sex: Sex;
  dateOfBirth: string;
  assessmentDate: string;
  ageYears: number;
  ageMonths: number;
  ageFormatted: string;
  normGroupKey: string;
  comparisonGroupDisplay: string;
  raterName?: string;
  grade?: string;
  adminNote?: string;
  isCompleted: boolean;
  rawScores: Record<AnyScaleCode, number>;
  scales: Record<ScaleCode, ScoreReportScale>;
  scaleList: ScoreReportScale[];
  validity: ScoreReportValidity;
  hasNorms: boolean;
  areasToExplore: AreaToExplore[];
  noAreasAbove60Narrative: string | null;
  itemsRated3: { id: number; text: string; scale: AnyScaleCode }[];
  itemsRated2: { id: number; text: string; scale: AnyScaleCode }[];
  openResponses: { id: number; question: string; answer: string }[];
  allResponses: { id: number; text: string; scale: AnyScaleCode; value: number }[];
}

/**
 * Calculates raw scores for all scales
 */
export function calculateRawScores(answers: Record<number, number>): Record<AnyScaleCode, number> {
  const rawScores: Record<AnyScaleCode, number> = {
    IN: 0,
    HY: 0,
    LP: 0,
    EF: 0,
    AG: 0,
    PR: 0,
    PI: 0,
    NI: 0,
  };

  for (const item of ITEMS) {
    const resp = answers[item.id];
    if (resp !== undefined && resp >= 0 && resp <= 3) {
      const points = item.key[resp];
      rawScores[item.scale] += points;
    }
  }

  return rawScores;
}

/**
 * Determines validity indices and message
 */
export function evaluateValidity(piRaw: number, niRaw: number): ScoreReportValidity {
  let piLevel: ValidityLevel = 'consistent';
  if (piRaw >= 5) {
    piLevel = 'likely_raised';
  } else if (piRaw === 4) {
    piLevel = 'possibly_raised';
  } else {
    piLevel = 'consistent';
  }

  let niLevel: ValidityLevel = 'consistent';
  if (niRaw >= 4) {
    niLevel = 'likely_raised';
  } else if (niRaw === 3) {
    niLevel = 'possibly_raised';
  } else {
    niLevel = 'consistent';
  }

  // Level precedence: likely_raised > possibly_raised > consistent
  let overallLevel: ValidityLevel = 'consistent';
  if (piLevel === 'likely_raised' || niLevel === 'likely_raised') {
    overallLevel = 'likely_raised';
  } else if (piLevel === 'possibly_raised' || niLevel === 'possibly_raised') {
    overallLevel = 'possibly_raised';
  } else {
    overallLevel = 'consistent';
  }

  const msg = VALIDITY_MESSAGES[overallLevel];

  let subtext = `Positive Impression (PI) raw score: ${piRaw} of 6 · Negative Impression (NI) raw score: ${niRaw} of 6.`;

  return {
    piRaw,
    niRaw,
    piLevel,
    niLevel,
    overallLevel,
    title: msg.title,
    body: msg.body,
    subtext,
  };
}

/**
 * Format T-Score according to Section 4:
 * T = 90 displayed as "90+", T = 40 displayed as "≤40"
 */
export function formatTScoreDisplay(tScore: number | null): string {
  if (tScore === null) return 'No norms';
  if (tScore >= 90) return '90+';
  if (tScore <= 40) return '≤40';
  return String(tScore);
}

/**
 * Deterministically generates the complete clinical report
 */
export function generateAssessmentReport(
  childId: string,
  childName: string,
  sex: Sex,
  dateOfBirth: string,
  assessmentDate: string,
  ageYears: number,
  ageMonths: number,
  answers: Record<number, number>,
  openAnswers: Record<number, string> = {},
  allNorms: AllNormTables,
  raterName?: string,
  grade?: string,
  adminNote?: string,
): ScoredAssessmentReport {
  const normGroupKey = getNormGroupKey(sex, ageYears);
  const comparisonGroupDisplay = formatNormGroupDisplay(normGroupKey);
  const normTable: NormTableData | undefined = allNorms[normGroupKey];
  const hasNorms = !!normTable && normTable.status === 'ready';

  const rawScores = calculateRawScores(answers);
  const validity = evaluateValidity(rawScores.PI, rawScores.NI);

  const scalesRecord: Partial<Record<ScaleCode, ScoreReportScale>> = {};
  const scaleList: ScoreReportScale[] = [];

  for (const code of SCALE_CODES) {
    const meta = CONTENT_SCALES[code];
    const raw = rawScores[code];
    let tScore: number | null = null;
    let percentile: number | null = null;
    let bandWording: string | null = null;

    if (hasNorms && normTable[code] && normTable[code][raw] !== undefined) {
      tScore = normTable[code][raw];
      percentile = calculateApproxPercentile(tScore);
      bandWording = getDescriptiveBand(tScore);
    }

    const scaleData: ScoreReportScale = {
      code,
      name: meta.name,
      description: meta.description,
      rawScore: raw,
      maxRaw: meta.maxRaw,
      tScore,
      tScoreDisplay: formatTScoreDisplay(tScore),
      percentile,
      bandWording,
      hasNorms: tScore !== null,
    };

    scalesRecord[code] = scaleData;
    scaleList.push(scaleData);
  }

  // Areas that may be worth exploring: only scales with T >= 60, sorted from highest T
  const areasToExplore: AreaToExplore[] = [];
  const sexNoun = sex === 'F' ? 'girls' : 'boys';

  if (hasNorms) {
    const eligible = scaleList
      .filter((s) => s.tScore !== null && s.tScore >= 60)
      .sort((a, b) => (b.tScore ?? 0) - (a.tScore ?? 0));

    for (const item of eligible) {
      if (item.tScore !== null && item.percentile !== null && item.bandWording !== null) {
        const narrative = `The parent’s ratings on items about ${item.description} are ${item.bandWording}. About ${item.percentile}% of ${sexNoun} this age in the comparison group received a lower score. This may be worth exploring further in interview and alongside other sources, such as teacher reports and observation.`;

        areasToExplore.push({
          scaleCode: item.code,
          scaleName: item.name,
          description: item.description,
          tScore: item.tScore,
          percentile: item.percentile,
          bandWording: item.bandWording,
          narrative,
        });
      }
    }
  }

  const noAreasAbove60Narrative =
    hasNorms && areasToExplore.length === 0
      ? `No scale is at T 60 or above. The parent’s ratings fall within or below the typical range for ${sexNoun} this age.`
      : null;

  // Statements rated "very much true" (3) and "pretty much true" (2)
  const itemsRated3: { id: number; text: string; scale: AnyScaleCode }[] = [];
  const itemsRated2: { id: number; text: string; scale: AnyScaleCode }[] = [];
  const allResponses: { id: number; text: string; scale: AnyScaleCode; value: number }[] = [];

  for (const item of ITEMS) {
    const val = answers[item.id] ?? 0;
    allResponses.push({ id: item.id, text: item.text, scale: item.scale, value: val });
    if (val === 3) {
      itemsRated3.push({ id: item.id, text: item.text, scale: item.scale });
    } else if (val === 2) {
      itemsRated2.push({ id: item.id, text: item.text, scale: item.scale });
    }
  }

  // Open questions
  const openResponses = [
    {
      id: 1,
      question: 'Do you have any other concerns about your child?',
      answer: openAnswers[1]?.trim() || '(No additional concerns noted by parent)',
    },
    {
      id: 2,
      question: 'What strengths or skills does your child have?',
      answer: openAnswers[2]?.trim() || '(No strengths or skills listed by parent)',
    },
  ];

  const totalAnswered = Object.keys(answers).length;
  const isCompleted = totalAnswered === 43;

  return {
    childId,
    childName,
    sex,
    dateOfBirth,
    assessmentDate,
    ageYears,
    ageMonths,
    ageFormatted: `${ageYears} years, ${ageMonths} months`,
    normGroupKey,
    comparisonGroupDisplay,
    raterName,
    grade,
    adminNote,
    isCompleted,
    rawScores,
    scales: scalesRecord as Record<ScaleCode, ScoreReportScale>,
    scaleList,
    validity,
    hasNorms,
    areasToExplore,
    noAreasAbove60Narrative,
    itemsRated3,
    itemsRated2,
    openResponses,
    allResponses,
  };
}

/**
 * Acceptance test verification suite matching Section 11 specifications
 */
export interface AcceptanceTestResult {
  name: string;
  expected: string;
  actual: string;
  passed: boolean;
  details: Record<string, unknown>;
}

export function runAcceptanceTests(norms: AllNormTables): {
  allPassed: boolean;
  results: AcceptanceTestResult[];
} {
  const results: AcceptanceTestResult[] = [];

  // Test 1: All 0
  const all0Answers: Record<number, number> = {};
  for (let i = 1; i <= 43; i++) all0Answers[i] = 0;
  const raw0 = calculateRawScores(all0Answers);
  const val0 = evaluateValidity(raw0.PI, raw0.NI);
  const pass0 =
    raw0.IN === 0 &&
    raw0.HY === 0 &&
    raw0.LP === 0 &&
    raw0.EF === 0 &&
    raw0.AG === 0 &&
    raw0.PR === 0 &&
    raw0.PI === 2 &&
    raw0.NI === 2 &&
    val0.overallLevel === 'consistent';

  results.push({
    name: 'Acceptance Test 1: All 0 Answers',
    expected: 'IN 0, HY 0, LP 0, EF 0, AG 0, PR 0, PI 2, NI 2 | Validity: Consistent',
    actual: `IN ${raw0.IN}, HY ${raw0.HY}, LP ${raw0.LP}, EF ${raw0.EF}, AG ${raw0.AG}, PR ${raw0.PR}, PI ${raw0.PI}, NI ${raw0.NI} | Validity: ${val0.overallLevel}`,
    passed: pass0,
    details: { rawScores: raw0, validity: val0 },
  });

  // Test 2: All 1
  const all1Answers: Record<number, number> = {};
  for (let i = 1; i <= 43; i++) all1Answers[i] = 1;
  const raw1 = calculateRawScores(all1Answers);
  const val1 = evaluateValidity(raw1.PI, raw1.NI);
  const pass1 =
    raw1.IN === 5 &&
    raw1.HY === 6 &&
    raw1.LP === 5 &&
    raw1.EF === 5 &&
    raw1.AG === 5 &&
    raw1.PR === 5 &&
    raw1.PI === 0 &&
    raw1.NI === 2 &&
    val1.overallLevel === 'consistent';

  results.push({
    name: 'Acceptance Test 2: All 1 Answers',
    expected: 'IN 5, HY 6, LP 5, EF 5, AG 5, PR 5, PI 0, NI 2 | Validity: Consistent',
    actual: `IN ${raw1.IN}, HY ${raw1.HY}, LP ${raw1.LP}, EF ${raw1.EF}, AG ${raw1.AG}, PR ${raw1.PR}, PI ${raw1.PI}, NI ${raw1.NI} | Validity: ${val1.overallLevel}`,
    passed: pass1,
    details: { rawScores: raw1, validity: val1 },
  });

  // Test 3: All 2
  const all2Answers: Record<number, number> = {};
  for (let i = 1; i <= 43; i++) all2Answers[i] = 2;
  const raw2 = calculateRawScores(all2Answers);
  const val2 = evaluateValidity(raw2.PI, raw2.NI);
  const pass2 =
    raw2.IN === 10 &&
    raw2.HY === 12 &&
    raw2.LP === 10 &&
    raw2.EF === 10 &&
    raw2.AG === 10 &&
    raw2.PR === 10 &&
    raw2.PI === 0 &&
    raw2.NI === 4 &&
    val2.overallLevel === 'likely_raised';

  results.push({
    name: 'Acceptance Test 3: All 2 Answers',
    expected: 'IN 10, HY 12, LP 10, EF 10, AG 10, PR 10, PI 0, NI 4 | Validity: Likely raised (NI)',
    actual: `IN ${raw2.IN}, HY ${raw2.HY}, LP ${raw2.LP}, EF ${raw2.EF}, AG ${raw2.AG}, PR ${raw2.PR}, PI ${raw2.PI}, NI ${raw2.NI} | Validity: ${val2.overallLevel}`,
    passed: pass2,
    details: { rawScores: raw2, validity: val2 },
  });

  // Test 4: All 3
  const all3Answers: Record<number, number> = {};
  for (let i = 1; i <= 43; i++) all3Answers[i] = 3;
  const raw3 = calculateRawScores(all3Answers);
  const val3 = evaluateValidity(raw3.PI, raw3.NI);
  const pass3 =
    raw3.IN === 15 &&
    raw3.HY === 18 &&
    raw3.LP === 15 &&
    raw3.EF === 15 &&
    raw3.AG === 15 &&
    raw3.PR === 15 &&
    raw3.PI === 4 &&
    raw3.NI === 4 &&
    val3.overallLevel === 'likely_raised';

  results.push({
    name: 'Acceptance Test 4: All 3 Answers',
    expected: 'IN 15, HY 18, LP 15, EF 15, AG 15, PR 15, PI 4, NI 4 | Validity: Likely raised (NI)',
    actual: `IN ${raw3.IN}, HY ${raw3.HY}, LP ${raw3.LP}, EF ${raw3.EF}, AG ${raw3.AG}, PR ${raw3.PR}, PI ${raw3.PI}, NI ${raw3.NI} | Validity: ${val3.overallLevel}`,
    passed: pass3,
    details: { rawScores: raw3, validity: val3 },
  });

  const allPassed = results.every((r) => r.passed);
  return { allPassed, results };
}
