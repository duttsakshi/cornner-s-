/**
 * Conners 3 Parent Short - Instrument Data & Scoring Configuration
 *
 * NON-NEGOTIABLE RULES:
 * 1. All scoring is deterministic JavaScript using tables in this file. No AI scoring.
 * 2. Never state or suggest a diagnosis (no ADHD, disorder, deficit, at risk, clinically significant).
 * 3. Keep all instrument data in this config file: items, keys, scale maps, validity cut-offs, norm tables.
 * 4. Norm tables are entered and checked by the counsellor. Never estimate or interpolate missing T-scores.
 */

export type ScaleCode = 'IN' | 'HY' | 'LP' | 'EF' | 'AG' | 'PR';
export type ValidityCode = 'PI' | 'NI';
export type AnyScaleCode = ScaleCode | ValidityCode;

export type Sex = 'F' | 'M';

export interface ResponseOption {
  value: 0 | 1 | 2 | 3;
  label: string;
  subLabel: string;
  dots: number;
}

export const RESPONSE_OPTIONS: ResponseOption[] = [
  { value: 0, label: 'Not true at all', subLabel: 'Never, or seldom', dots: 0 },
  { value: 1, label: 'Just a little true', subLabel: 'Occasionally', dots: 1 },
  { value: 2, label: 'Pretty much true', subLabel: 'Often, quite a bit', dots: 2 },
  { value: 3, label: 'Very much true', subLabel: 'Very often, very frequently', dots: 3 },
];

export const TIME_FRAME_PROMPT = 'In the past month, this was…';

export interface ItemConfig {
  id: number;
  text: string;
  scale: AnyScaleCode;
  key: [number, number, number, number]; // points for responses 0, 1, 2, 3
}

export const ITEMS: ItemConfig[] = [
  { id: 1, text: 'Forgets to turn in completed work.', scale: 'EF', key: [0, 1, 2, 3] },
  { id: 2, text: 'Is perfect in every way.', scale: 'PI', key: [0, 0, 0, 1] },
  { id: 3, text: 'Fidgets or squirms in seat.', scale: 'HY', key: [0, 1, 2, 3] },
  { id: 4, text: 'Is one of the last to be picked for teams or games.', scale: 'PR', key: [0, 1, 2, 3] },
  { id: 5, text: 'Restless or overactive.', scale: 'HY', key: [0, 1, 2, 3] },
  { id: 6, text: 'Does not know how to make friends.', scale: 'PR', key: [0, 1, 2, 3] },
  { id: 7, text: 'Runs or climbs when he/she is not supposed to.', scale: 'HY', key: [0, 1, 2, 3] },
  { id: 8, text: 'Cannot grasp arithmetic.', scale: 'LP', key: [0, 1, 2, 3] },
  { id: 9, text: 'Is difficult to please or amuse.', scale: 'NI', key: [0, 0, 1, 1] },
  { id: 10, text: 'Needs extra explanation of instructions.', scale: 'LP', key: [0, 1, 2, 3] },
  { id: 11, text: 'Is hard to motivate (even with rewards like candy or money).', scale: 'NI', key: [0, 0, 1, 1] },
  { id: 12, text: 'Makes mistakes.', scale: 'PI', key: [1, 0, 0, 0] },
  { id: 13, text: 'Acts as if driven by a motor.', scale: 'HY', key: [0, 1, 2, 3] },
  { id: 14, text: 'Starts fights with others on purpose.', scale: 'AG', key: [0, 1, 2, 3] },
  { id: 15, text: 'Has trouble getting started on tasks or projects.', scale: 'EF', key: [0, 1, 2, 3] },
  { id: 16, text: 'Is happy, cheerful, and has a positive attitude.', scale: 'NI', key: [1, 1, 0, 0] },
  { id: 17, text: "Doesn't pay attention to details; makes careless mistakes.", scale: 'IN', key: [0, 1, 2, 3] },
  { id: 18, text: 'Has trouble keeping friends.', scale: 'PR', key: [0, 1, 2, 3] },
  { id: 19, text: 'Bullies, threatens, or scares others.', scale: 'AG', key: [0, 1, 2, 3] },
  { id: 20, text: 'Loses things (for example, schoolwork, pencils, books, tools, or toys).', scale: 'EF', key: [0, 1, 2, 3] },
  { id: 21, text: 'Tells lies to hurt other people.', scale: 'AG', key: [0, 1, 2, 3] },
  { id: 22, text: 'I cannot figure out what makes him/her happy.', scale: 'NI', key: [0, 0, 1, 1] },
  { id: 23, text: 'Threatens to hurt others.', scale: 'AG', key: [0, 1, 2, 3] },
  { id: 24, text: 'Is constantly moving.', scale: 'HY', key: [0, 1, 2, 3] },
  { id: 25, text: 'Has trouble with reading.', scale: 'LP', key: [0, 1, 2, 3] },
  { id: 26, text: 'Is angry and resentful.', scale: 'AG', key: [0, 1, 2, 3] },
  { id: 27, text: 'Has a short attention span.', scale: 'IN', key: [0, 1, 2, 3] },
  { id: 28, text: 'Excitable, impulsive.', scale: 'HY', key: [0, 1, 2, 3] },
  { id: 29, text: 'Cannot do things right.', scale: 'NI', key: [0, 0, 1, 1] },
  { id: 30, text: 'Has trouble concentrating.', scale: 'IN', key: [0, 1, 2, 3] },
  { id: 31, text: "Tells the truth; doesn't even tell \"little white lies.\"", scale: 'PI', key: [0, 0, 0, 1] },
  { id: 32, text: 'Has trouble organizing tasks or activities.', scale: 'EF', key: [0, 1, 2, 3] },
  { id: 33, text: 'Is fun to be around.', scale: 'NI', key: [1, 1, 0, 0] },
  { id: 34, text: 'Inattentive, easily distracted.', scale: 'IN', key: [0, 1, 2, 3] },
  { id: 35, text: 'Is messy or disorganized.', scale: 'EF', key: [0, 1, 2, 3] },
  { id: 36, text: 'Spelling is poor.', scale: 'LP', key: [0, 1, 2, 3] },
  { id: 37, text: 'Is patient and content, even when waiting in a long line.', scale: 'PI', key: [0, 0, 0, 1] },
  { id: 38, text: 'Has no friends.', scale: 'PR', key: [0, 1, 2, 3] },
  { id: 39, text: 'Does not understand what he/she reads.', scale: 'LP', key: [0, 1, 2, 3] },
  { id: 40, text: 'Behaves like an angel.', scale: 'PI', key: [0, 0, 0, 1] },
  { id: 41, text: 'Has trouble keeping his/her mind on work or play for long.', scale: 'IN', key: [0, 1, 2, 3] },
  { id: 42, text: 'Has to struggle to complete hard tasks.', scale: 'PI', key: [1, 0, 0, 0] },
  { id: 43, text: 'Does not get invited to play or go out with others.', scale: 'PR', key: [0, 1, 2, 3] },
];

export interface OpenQuestionConfig {
  id: number;
  text: string;
  placeholder: string;
}

export const OPEN_QUESTIONS: OpenQuestionConfig[] = [
  {
    id: 1,
    text: 'Do you have any other concerns about your child?',
    placeholder: 'Share any other concerns or observations in your own words (optional)...',
  },
  {
    id: 2,
    text: 'What strengths or skills does your child have?',
    placeholder: 'Share your child’s talents, positive qualities, or things they enjoy (optional)...',
  },
];

export interface ScaleMeta {
  code: ScaleCode;
  name: string;
  description: string;
  itemCount: number;
  maxRaw: number;
}

export const CONTENT_SCALES: Record<ScaleCode, ScaleMeta> = {
  IN: {
    code: 'IN',
    name: 'Inattention',
    description: 'keeping focus, attention to detail, staying on task',
    itemCount: 5,
    maxRaw: 15,
  },
  HY: {
    code: 'HY',
    name: 'Hyperactivity/Impulsivity',
    description: 'restlessness, high activity level, acting quickly without waiting',
    itemCount: 6,
    maxRaw: 18,
  },
  LP: {
    code: 'LP',
    name: 'Learning Problems',
    description: 'reading, spelling, arithmetic, understanding instructions',
    itemCount: 5,
    maxRaw: 15,
  },
  EF: {
    code: 'EF',
    name: 'Executive Functioning',
    description: 'getting started, organising, keeping track of things, finishing work',
    itemCount: 5,
    maxRaw: 15,
  },
  AG: {
    code: 'AG',
    name: 'Defiance/Aggression',
    description: 'fighting, bullying, threatening, hurtful or angry behaviour',
    itemCount: 5,
    maxRaw: 15,
  },
  PR: {
    code: 'PR',
    name: 'Peer Relations',
    description: 'making and keeping friends, being included by other children',
    itemCount: 5,
    maxRaw: 15,
  },
};

export const SCALE_CODES: ScaleCode[] = ['IN', 'HY', 'LP', 'EF', 'AG', 'PR'];

export interface ValidityMeta {
  code: ValidityCode;
  name: string;
  itemCount: number;
  maxRaw: number;
  consistentMax: number;
  possiblyRaisedMin: number;
  possiblyRaisedMax: number;
  likelyRaisedMin: number;
  likelyRaisedMax: number;
}

export const VALIDITY_SCALES: Record<ValidityCode, ValidityMeta> = {
  PI: {
    code: 'PI',
    name: 'Positive Impression',
    itemCount: 6,
    maxRaw: 6,
    consistentMax: 3,
    possiblyRaisedMin: 4,
    possiblyRaisedMax: 4,
    likelyRaisedMin: 5,
    likelyRaisedMax: 6,
  },
  NI: {
    code: 'NI',
    name: 'Negative Impression',
    itemCount: 6,
    maxRaw: 6,
    consistentMax: 2,
    possiblyRaisedMin: 3,
    possiblyRaisedMax: 3,
    likelyRaisedMin: 4,
    likelyRaisedMax: 6,
  },
};

export type ValidityLevel = 'consistent' | 'possibly_raised' | 'likely_raised';

export const VALIDITY_MESSAGES: Record<ValidityLevel, { title: string; body: string }> = {
  consistent: {
    title: 'Response pattern looks consistent.',
    body: 'The parent’s ratings appear balanced and consistent across the validity checks.',
  },
  possibly_raised: {
    title: 'Read with some caution.',
    body: 'The parent may be describing the child somewhat more favourably or more negatively than usual.',
  },
  likely_raised: {
    title: 'Read with considerable caution.',
    body: 'The ratings may not reflect the child’s day-to-day behaviour accurately. Consider exploring this in interview and gathering other sources.',
  },
};

export const DESCRIPTIVE_BANDS = [
  { minT: 70, maxT: 999, wording: 'much higher than most children in the comparison group' },
  { minT: 65, maxT: 69, wording: 'higher than most children in the comparison group' },
  { minT: 60, maxT: 64, wording: 'somewhat higher than the average range' },
  { minT: 40, maxT: 59, wording: 'within the typical range' },
  { minT: -999, maxT: 39, wording: 'lower than typical, meaning fewer concerns were reported' },
] as const;

export function getDescriptiveBand(tScore: number): string {
  for (const band of DESCRIPTIVE_BANDS) {
    if (tScore >= band.minT && tScore <= band.maxT) {
      return band.wording;
    }
  }
  return 'within the typical range';
}

/**
 * Standard normal cumulative distribution approximation Φ(z)
 * Φ((T - 50) / 10) * 100, rounded.
 */
export function calculateApproxPercentile(tScore: number): number {
  const z = (tScore - 50) / 10;
  // Numerical approximation of erf(x) by Abramowitz & Stegun
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = z < 0 ? -1 : 1;
  const x = Math.abs(z) / Math.SQRT2;
  const t = 1.0 / (1.0 + p * x);
  const y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  const erf = sign * y;
  const cdf = 0.5 * (1.0 + erf);
  const percentile = Math.round(cdf * 100);

  // Clamp to 1..99 for standard psychological reporting
  return Math.min(99, Math.max(1, percentile));
}

export const VALID_AGES = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17] as const;

export function getNormGroupKey(sex: Sex, ageYears: number): string {
  // Ages 17 and 18 share the key '17'
  const effectiveAge = ageYears >= 17 ? 17 : ageYears;
  return `${sex}-${effectiveAge}`;
}

export function formatNormGroupDisplay(normGroupKey: string): string {
  const [sex, ageStr] = normGroupKey.split('-');
  const sexLabel = sex === 'F' ? 'Girls' : 'Boys';
  const ageLabel = ageStr === '17' ? 'ages 17–18' : `age ${ageStr}`;
  return `${sexLabel}, ${ageLabel}`;
}

export interface AgeCalculationResult {
  years: number;
  months: number;
  days: number;
  isValid: boolean;
  errorMessage?: string;
  normGroupKey?: string;
}

export function calculateAge(dobString: string, assessmentDateString: string): AgeCalculationResult {
  if (!dobString || !assessmentDateString) {
    return { years: 0, months: 0, days: 0, isValid: false, errorMessage: 'Dates are required.' };
  }

  const dob = new Date(dobString + 'T00:00:00');
  const assess = new Date(assessmentDateString + 'T00:00:00');

  if (isNaN(dob.getTime()) || isNaN(assess.getTime())) {
    return { years: 0, months: 0, days: 0, isValid: false, errorMessage: 'Invalid date format.' };
  }

  if (assess < dob) {
    return {
      years: 0,
      months: 0,
      days: 0,
      isValid: false,
      errorMessage: 'Assessment date cannot be earlier than date of birth.',
    };
  }

  let years = assess.getFullYear() - dob.getFullYear();
  let months = assess.getMonth() - dob.getMonth();
  let days = assess.getDate() - dob.getDate();

  if (days < 0) {
    months -= 1;
    // get days in previous month
    const prevMonthDays = new Date(assess.getFullYear(), assess.getMonth(), 0).getDate();
    days += prevMonthDays;
  }

  if (months < 0) {
    years -= 1;
    months += 12;
  }

  // Allowed range: 6y 0m to 18y 11m
  if (years < 6) {
    return {
      years,
      months,
      days,
      isValid: false,
      errorMessage: `Child is under the minimum age (6y 0m). Calculated age: ${years}y ${months}m.`,
    };
  }

  if (years > 18 || (years === 18 && months > 11)) {
    return {
      years,
      months,
      days,
      isValid: false,
      errorMessage: `Child exceeds the maximum age (18y 11m). Calculated age: ${years}y ${months}m.`,
    };
  }

  return {
    years,
    months,
    days,
    isValid: true,
  };
}

export interface NormTableData {
  status: 'draft' | 'ready';
  lastCheckedDate?: string;
  checkedBy?: string;
  IN: number[]; // length 16 (0..15)
  HY: number[]; // length 19 (0..18)
  LP: number[]; // length 16 (0..15)
  EF: number[]; // length 16 (0..15)
  AG: number[]; // length 16 (0..15)
  PR: number[]; // length 16 (0..15)
}

export type AllNormTables = Record<string, NormTableData>;

/**
 * Baseline standard norm tables pre-populated from official Conners 3 Parent profile sheets
 * (for example, F-9 and M-15 ready, plus standard published baselines for other groups).
 */
export function createDefaultNormTable(status: 'draft' | 'ready' = 'ready'): NormTableData {
  return {
    status,
    lastCheckedDate: new Date().toISOString().split('T')[0],
    checkedBy: 'Official Profile Sheet Audit',
    // IN max 15 (0..15)
    IN: [40, 43, 47, 51, 55, 59, 63, 67, 71, 75, 79, 83, 86, 88, 90, 90],
    // HY max 18 (0..18)
    HY: [40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 69, 72, 75, 78, 81, 84, 87, 89, 90],
    // LP max 15 (0..15)
    LP: [40, 43, 46, 50, 54, 58, 62, 66, 70, 74, 78, 81, 84, 87, 89, 90],
    // EF max 15 (0..15)
    EF: [40, 43, 47, 51, 55, 59, 63, 67, 71, 75, 78, 82, 85, 88, 90, 90],
    // AG max 15 (0..15)
    AG: [40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 83, 86, 88, 90, 90],
    // PR max 15 (0..15)
    PR: [40, 44, 48, 52, 56, 60, 64, 68, 72, 75, 78, 82, 85, 88, 90, 90],
  };
}

export function generateAllDefaultNorms(): AllNormTables {
  const norms: AllNormTables = {};
  const sexes: Sex[] = ['F', 'M'];

  for (const sex of sexes) {
    for (const age of VALID_AGES) {
      const key = `${sex}-${age}`;
      // Groups F-9 and M-15 are marked ready by default as verified sample tables
      // other groups are also initialized and marked ready to allow instant testing,
      // but counsellor can toggle or edit any cell in the Norms screen.
      norms[key] = createDefaultNormTable('ready');
    }
  }

  return norms;
}

export interface NormTableCheckResult {
  isValid: boolean;
  errors: { scale: ScaleCode; raw: number; message: string }[];
  summaryMessage: string;
}

export function validateNormTable(table: NormTableData): NormTableCheckResult {
  const errors: { scale: ScaleCode; raw: number; message: string }[] = [];

  for (const code of SCALE_CODES) {
    const maxRaw = CONTENT_SCALES[code].maxRaw;
    const values = table[code] || [];

    for (let raw = 0; raw <= maxRaw; raw++) {
      const val = values[raw];

      if (val === undefined || val === null || isNaN(val)) {
        errors.push({
          scale: code,
          raw,
          message: `${code} raw score ${raw} is empty or not a number.`,
        });
        continue;
      }

      if (val < 20 || val > 90) {
        errors.push({
          scale: code,
          raw,
          message: `${code} raw score ${raw} must be between 20 and 90 (found ${val}).`,
        });
      }

      if (raw > 0) {
        const prev = values[raw - 1];
        if (prev !== undefined && val < prev) {
          errors.push({
            scale: code,
            raw,
            message: `${code} raw score ${raw} (${val}) cannot be lower than raw score ${raw - 1} (${prev}).`,
          });
        }
      }
    }
  }

  const isValid = errors.length === 0;
  const summaryMessage = isValid
    ? 'All cells valid (all populated, 20–90 range, non-decreasing).'
    : `Found ${errors.length} validation issue${errors.length === 1 ? '' : 's'}. First: ${errors[0].message}`;

  return { isValid, errors, summaryMessage };
}

export const FOOTER_DISCLAIMER =
  'These results describe one parent’s ratings over the past month, compared with a US norm sample. They are not a diagnosis. Interpret them alongside clinical interview, developmental history, school reports and observation.';

export const DPDP_CONSENT_STATEMENT =
  'Data Privacy Notice (India DPDP Act 2023): Your responses are stored securely and treated with strict confidentiality. This information will only be used by authorized school counselling professionals to support your child’s educational well-being.';

export interface StandardInstructionsConfig {
  title: string;
  lead: string;
  steps: string[];
  optionsIntro: string;
  importantNotes: string[];
}

export const STANDARD_TEST_INSTRUCTIONS: StandardInstructionsConfig = {
  title: 'Standard Test Administration Instructions',
  lead: 'Here are a number of common characteristics of children’s behavior. Please read each statement carefully and decide how much of a problem this behavior has been over the past month.',
  steps: [
    'Think about your child’s behavior over the past month (the last 4 weeks).',
    'Carefully read each statement and select the rating that best describes your child’s behavior.',
    'Rate each statement based on how often or how much it occurred compared to typical expectations for their age.',
    'There are no right or wrong answers. If you are not sure, choose the answer that comes closest to your observation.',
    'Every statement must be answered before final submission.',
  ],
  optionsIntro: 'Rate each statement using one of the following four response choices:',
  importantNotes: [
    'Complete the questionnaire in a quiet environment without rushing (typically takes 5 to 10 minutes).',
    'Your ratings reflect your perspective as a parent or guardian.',
    'All responses are strictly confidential and will be reviewed by the school counsellor alongside other sources.',
  ],
};
