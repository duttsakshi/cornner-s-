/**
 * Persistent Storage Layer for Conners 3 Parent Short
 * Uses browser localStorage with automatic syncing, JSON export/backup & restore.
 */

import {
  Sex,
  AllNormTables,
  generateAllDefaultNorms,
  calculateAge,
  getNormGroupKey,
} from './connersConfig';

export interface AssessmentRecord {
  id: string;
  childId: string;
  childName?: string;
  sex: Sex;
  dateOfBirth: string;
  assessmentDate: string;
  ageYears: number;
  ageMonths: number;
  normGroupKey: string;
  grade?: string;
  parentName?: string;
  adminNote?: string;
  status: 'in_progress' | 'completed';
  answers: Record<number, number>; // 1..43
  openAnswers: Record<number, string>; // 1, 2
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
}

const STORAGE_KEY_ASSESSMENTS = 'conners3_assessments_v1';
const STORAGE_KEY_NORMS = 'conners3_norm_tables_v1';
const STORAGE_KEY_SETTINGS = 'conners3_counsellor_settings_v1';

export interface CounsellorSettings {
  pin: string;
  counsellorName: string;
  schoolName: string;
}

const DEFAULT_SETTINGS: CounsellorSettings = {
  pin: '1234',
  counsellorName: 'School Counsellor',
  schoolName: 'Student Support Services',
};

// Initial sample assessment to show how the tool looks and works immediately
function getInitialSampleAssessments(): AssessmentRecord[] {
  const sampleAnswers: Record<number, number> = {
    1: 2, 2: 0, 3: 3, 4: 1, 5: 3, 6: 1, 7: 2, 8: 1, 9: 1, 10: 1,
    11: 1, 12: 0, 13: 2, 14: 0, 15: 3, 16: 2, 17: 2, 18: 1, 19: 0, 20: 2,
    21: 0, 22: 0, 23: 0, 24: 3, 25: 1, 26: 1, 27: 3, 28: 2, 29: 0, 30: 3,
    31: 0, 32: 2, 33: 2, 34: 3, 35: 2, 36: 0, 37: 0, 38: 0, 39: 0, 40: 0,
    41: 2, 42: 1, 43: 0
  };

  const sampleDateOfBirth = '2016-04-12';
  const sampleAssessmentDate = '2026-03-14';
  const ageRes = calculateAge(sampleDateOfBirth, sampleAssessmentDate);

  return [
    {
      id: 'sample-assessment-01',
      childId: 'STU-9402',
      childName: 'Aarav M.',
      sex: 'M',
      dateOfBirth: sampleDateOfBirth,
      assessmentDate: sampleAssessmentDate,
      ageYears: ageRes.years,
      ageMonths: ageRes.months,
      normGroupKey: getNormGroupKey('M', ageRes.years),
      grade: 'Grade 4',
      parentName: 'Sunita M. (Mother)',
      adminNote: 'Administered in-office; mother completed on tablet with counsellor present.',
      status: 'completed',
      answers: sampleAnswers,
      openAnswers: {
        1: 'Often forgets morning routine tasks and gets very restless during homework hour.',
        2: 'Very affectionate, creative with building blocks, and loves animal trivia.',
      },
      createdAt: '2026-03-14T09:30:00.000Z',
      updatedAt: '2026-03-14T09:48:00.000Z',
      completedAt: '2026-03-14T09:48:00.000Z',
    },
  ];
}

export function loadAssessments(): AssessmentRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ASSESSMENTS);
    if (!raw) {
      const initial = getInitialSampleAssessments();
      saveAssessments(initial);
      return initial;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to load assessments from localStorage:', err);
    return getInitialSampleAssessments();
  }
}

export function saveAssessments(records: AssessmentRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_ASSESSMENTS, JSON.stringify(records));
  } catch (err) {
    console.error('Failed to save assessments to localStorage:', err);
  }
}

export function saveSingleAssessment(record: AssessmentRecord): void {
  const records = loadAssessments();
  const index = records.findIndex((r) => r.id === record.id);
  if (index >= 0) {
    records[index] = record;
  } else {
    records.unshift(record);
  }
  saveAssessments(records);
}

export function deleteAssessment(id: string): void {
  const records = loadAssessments().filter((r) => r.id !== id);
  saveAssessments(records);
}

export function loadNorms(): AllNormTables {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_NORMS);
    if (!raw) {
      const initial = generateAllDefaultNorms();
      saveNorms(initial);
      return initial;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to load norms from localStorage:', err);
    return generateAllDefaultNorms();
  }
}

export function saveNorms(norms: AllNormTables): void {
  try {
    localStorage.setItem(STORAGE_KEY_NORMS, JSON.stringify(norms));
  } catch (err) {
    console.error('Failed to save norms to localStorage:', err);
  }
}

export function loadCounsellorSettings(): CounsellorSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (!raw) {
      saveCounsellorSettings(DEFAULT_SETTINGS);
      return DEFAULT_SETTINGS;
    }
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (err) {
    return DEFAULT_SETTINGS;
  }
}

export function saveCounsellorSettings(settings: CounsellorSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings:', err);
  }
}
