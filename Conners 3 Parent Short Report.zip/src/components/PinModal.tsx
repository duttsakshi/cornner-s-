import React, { useState } from 'react';
import { Lock, X, KeyRound, AlertCircle } from 'lucide-react';

interface PinModalProps {
  isOpen: boolean;
  expectedPin: string;
  onSuccess: () => void;
  onCancel: () => void;
  title?: string;
  description?: string;
}

export const PinModal: React.FC<PinModalProps> = ({
  isOpen,
  expectedPin,
  onSuccess,
  onCancel,
  title = 'Counsellor Access Verification',
  description = 'Enter your counsellor PIN to access clinician reports and dashboard.',
}) => {
  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === expectedPin) {
      setError(null);
      setPin('');
      onSuccess();
    } else {
      setError('Incorrect PIN. (Default counsellor PIN is 1234)');
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="pin-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-sm w-full p-6 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2 text-slate-800">
            <Lock className="w-4 h-4 text-[#1E5F74]" />
            <h3 id="pin-modal-title" className="font-semibold text-sm">
              {title}
            </h3>
          </div>
          <button
            onClick={() => {
              setError(null);
              setPin('');
              onCancel();
            }}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          {description}
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="pin-input" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Counsellor PIN
            </label>
            <div className="relative">
              <input
                id="pin-input"
                type="password"
                maxLength={8}
                autoFocus
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="••••"
                className="w-full h-12 text-center tracking-widest text-lg font-mono font-bold bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1E5F74] focus:bg-white"
              />
            </div>
            {error && (
              <div className="flex items-center gap-1.5 text-xs text-rose-600 mt-2 font-medium">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}
            <div className="text-[11px] text-slate-400 mt-2 text-center">
              Standard default PIN: <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">1234</code>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                setError(null);
                setPin('');
                onCancel();
              }}
              className="flex-1 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 text-xs font-semibold text-white bg-[#1E5F74] hover:bg-[#184d5e] rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Unlock
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
