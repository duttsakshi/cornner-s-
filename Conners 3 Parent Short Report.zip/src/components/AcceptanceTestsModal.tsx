import React, { useState, useMemo } from 'react';
import { AllNormTables, calculateAge, getNormGroupKey } from '../connersConfig';
import { runAcceptanceTests, generateAssessmentReport } from '../scoringEngine';
import { CheckCircle2, XCircle, ShieldCheck, X, Play, AlertTriangle } from 'lucide-react';

interface AcceptanceTestsModalProps {
  isOpen: boolean;
  onClose: () => void;
  norms: AllNormTables;
}

export const AcceptanceTestsModal: React.FC<AcceptanceTestsModalProps> = ({
  isOpen,
  onClose,
  norms,
}) => {
  const [testResults, setTestResults] = useState<{
    allPassed: boolean;
    results: {
      name: string;
      expected: string;
      actual: string;
      passed: boolean;
    }[];
  } | null>(null);

  // Run all suite tests including age & missing norms
  const handleRunTests = () => {
    const base = runAcceptanceTests(norms);
    const combinedResults = [...base.results];

    // Test 5: Age calculation test
    const ageTestRes = calculateAge('2010-03-15', '2026-03-14');
    const ageGroupF = getNormGroupKey('F', ageTestRes.years);
    const agePass = ageTestRes.years === 15 && ageTestRes.months === 11 && ageGroupF === 'F-15';

    combinedResults.push({
      name: 'Acceptance Test 5: Exact Age Calculation (DOB 2010-03-15, Assessment 2026-03-14)',
      expected: '15 years 11 months, group F-15',
      actual: `${ageTestRes.years} years ${ageTestRes.months} months, group ${ageGroupF}`,
      passed: agePass,
      details: { ageTestRes, ageGroupF },
    });

    // Test 6: 18-year-old maps to group 17
    const age18Group = getNormGroupKey('M', 18);
    const age18Pass = age18Group === 'M-17';
    combinedResults.push({
      name: 'Acceptance Test 6: Age 18 Norm Group Mapping',
      expected: 'Norm group key M-17 (ages 17 & 18 share group 17)',
      actual: `Norm group key ${age18Group}`,
      passed: age18Pass,
      details: { age18Group },
    });

    // Test 7: Missing norms handling
    // Create a dummy group with status: 'draft'
    const draftNorms: AllNormTables = {
      ...norms,
      'F-9': {
        ...norms['F-9'],
        status: 'draft',
      },
    };
    const reportNoNorms = generateAssessmentReport(
      'TEST-ID',
      'Test Child',
      'F',
      '2017-03-01',
      '2026-03-14',
      9,
      0,
      { 1: 0 },
      {},
      draftNorms
    );
    const missingNormsPass =
      reportNoNorms.hasNorms === false &&
      reportNoNorms.scales.IN.tScore === null &&
      reportNoNorms.scales.IN.rawScore !== undefined;

    combinedResults.push({
      name: 'Acceptance Test 7: Missing/Unchecked Norms Handling',
      expected: 'T-score is null / unavailable, raw score retained, validity computed',
      actual: `T-score is ${reportNoNorms.scales.IN.tScore ?? 'null (unavailable)'}, raw IN is ${reportNoNorms.scales.IN.rawScore}`,
      passed: missingNormsPass,
      details: { hasNorms: reportNoNorms.hasNorms, inScore: reportNoNorms.scales.IN },
    });

    setTestResults({
      allPassed: combinedResults.every((r) => r.passed),
      results: combinedResults,
    });
  };

  // Run on mount or when modal opens
  React.useEffect(() => {
    if (isOpen) {
      handleRunTests();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="acceptance-tests-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#1E5F74]" />
            <div>
              <h2 id="acceptance-tests-title" className="text-lg font-serif font-bold text-slate-900">
                Deterministic Scoring Acceptance Tests
              </h2>
              <p className="text-xs text-slate-500">
                Verifying against Section 11 specifications
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {testResults && (
          <div
            className={`p-4 rounded-xl border flex items-center justify-between ${
              testResults.allPassed
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {testResults.allPassed ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              ) : (
                <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
              )}
              <span className="font-semibold text-sm">
                {testResults.allPassed
                  ? 'All 7 acceptance tests passed perfectly.'
                  : 'Some acceptance tests failed.'}
              </span>
            </div>
            <button
              onClick={handleRunTests}
              className="px-3 py-1 text-xs font-semibold bg-white border border-slate-200 rounded-lg shadow-2xs hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Re-run tests
            </button>
          </div>
        )}

        <div className="space-y-3">
          {testResults?.results.map((res, index) => (
            <div
              key={index}
              className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5 text-xs"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800">{res.name}</span>
                <span
                  className={`inline-flex items-center gap-1 font-semibold px-2 py-0.5 rounded-full ${
                    res.passed
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {res.passed ? 'PASSED' : 'FAILED'}
                </span>
              </div>
              <div className="text-slate-500 font-mono">
                <span className="font-semibold text-slate-700">Expected: </span>
                {res.expected}
              </div>
              <div className="text-slate-600 font-mono">
                <span className="font-semibold text-slate-700">Actual: </span>
                {res.actual}
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end pt-2 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
