import React, { useState } from 'react';
import { AssessmentRecord, CounsellorSettings } from '../storage';
import {
  Plus,
  Table,
  Search,
  CheckCircle2,
  Clock,
  Trash2,
  FileSpreadsheet,
  ShieldCheck,
  LogOut,
  Settings,
  ExternalLink,
  ChevronRight,
  UserCheck,
  Calendar,
  Layers,
} from 'lucide-react';

interface CounsellorDashboardProps {
  assessments: AssessmentRecord[];
  onSelectAssessment: (record: AssessmentRecord) => void;
  onLaunchParentMode: (record: AssessmentRecord) => void;
  onOpenNewAssessmentModal: () => void;
  onOpenNormTables: () => void;
  onOpenAcceptanceTests: () => void;
  onDeleteAssessment: (id: string) => void;
  onLockDashboard: () => void;
  settings: CounsellorSettings;
  onUpdateSettings: (settings: CounsellorSettings) => void;
}

export const CounsellorDashboard: React.FC<CounsellorDashboardProps> = ({
  assessments,
  onSelectAssessment,
  onLaunchParentMode,
  onOpenNewAssessmentModal,
  onOpenNormTables,
  onOpenAcceptanceTests,
  onDeleteAssessment,
  onLockDashboard,
  settings,
  onUpdateSettings,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'in_progress' | 'completed'>('all');
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [pinInput, setPinInput] = useState<string>(settings.pin);
  const [counsellorNameInput, setCounsellorNameInput] = useState<string>(settings.counsellorName);
  const [schoolNameInput, setSchoolNameInput] = useState<string>(settings.schoolName);
  const [settingsSaved, setSettingsSaved] = useState<boolean>(false);

  const filteredAssessments = assessments.filter((item) => {
    const matchesSearch =
      item.childId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.childName && item.childName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (item.parentName && item.parentName.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus =
      statusFilter === 'all' || item.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      pin: pinInput.trim() || '1234',
      counsellorName: counsellorNameInput.trim() || 'School Counsellor',
      schoolName: schoolNameInput.trim() || 'Student Support Services',
    });
    setSettingsSaved(true);
    setTimeout(() => {
      setSettingsSaved(false);
      setIsSettingsOpen(false);
    }, 1500);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Header Bar */}
      <header className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#1E5F74] mb-1">
            <span>{settings.schoolName}</span>
            <span aria-hidden="true">·</span>
            <span>Clinician Portal</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 tracking-tight">
            Conners 3 Parent Short
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Logged in as {settings.counsellorName} · Deterministic Scoring & Clinical Reporting
          </p>
        </div>

        {/* Header Actions */}
        <div className="flex flex-wrap items-center gap-2 pt-2 md:pt-0">
          <button
            onClick={onOpenNormTables}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            title="Inspect and edit profile norm tables"
          >
            <Table className="w-3.5 h-3.5" />
            <span>Norm tables</span>
          </button>

          <button
            onClick={onOpenAcceptanceTests}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            title="Run non-negotiable acceptance tests"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#1E5F74]" />
            <span>Run tests</span>
          </button>

          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            title="Counsellor Settings"
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            onClick={onLockDashboard}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors cursor-pointer"
            title="Lock clinician portal (switch to parent view)"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Lock view</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-7 shadow-xs space-y-5">
        {/* Controls Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by ID, name, or rater..."
              className="w-full h-10 pl-9 pr-3 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74] focus:bg-white"
            />
          </div>

          {/* Filter & Primary CTA */}
          <div className="flex items-center gap-2">
            {/* Status Filter Tabs */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200/70">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  statusFilter === 'all'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({assessments.length})
              </button>
              <button
                onClick={() => setStatusFilter('in_progress')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  statusFilter === 'in_progress'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                In progress
              </button>
              <button
                onClick={() => setStatusFilter('completed')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  statusFilter === 'completed'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Completed
              </button>
            </div>

            <button
              onClick={onOpenNewAssessmentModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#1E5F74] hover:bg-[#184d5e] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Start new assessment</span>
            </button>
          </div>
        </div>

        {/* Assessments List Table */}
        {filteredAssessments.length > 0 ? (
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-100/70 border-b border-slate-200 text-xs font-semibold text-slate-700 uppercase tracking-wider">
                  <th scope="col" className="py-3 px-4">Child ID & Name</th>
                  <th scope="col" className="py-3 px-4">Sex / Age</th>
                  <th scope="col" className="py-3 px-4">Comparison Group</th>
                  <th scope="col" className="py-3 px-4">Assessment Date</th>
                  <th scope="col" className="py-3 px-4 text-center">Status</th>
                  <th scope="col" className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAssessments.map((record) => {
                  const totalAnswered = Object.keys(record.answers || {}).length;
                  const isCompleted = record.status === 'completed';

                  return (
                    <tr key={record.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">
                          {record.childId}
                        </div>
                        {record.childName && (
                          <div className="text-xs text-slate-500 font-medium">
                            {record.childName}
                          </div>
                        )}
                        {record.parentName && (
                          <div className="text-[11px] text-slate-400">
                            Rater: {record.parentName}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-700">
                        <span className="font-semibold">
                          {record.sex === 'F' ? 'Female' : 'Male'}
                        </span>
                        <span className="block text-slate-500">
                          {record.ageYears}y {record.ageMonths}m
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-xs font-medium text-slate-700">
                        <span className="font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold">
                          {record.normGroupKey}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600 tabular-nums">
                        {record.assessmentDate}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {isCompleted ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                            <CheckCircle2 className="w-3 h-3" />
                            Completed
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                            <Clock className="w-3 h-3" />
                            {totalAnswered} of 43 answered
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="inline-flex items-center gap-2">
                          {isCompleted ? (
                            <button
                              onClick={() => onSelectAssessment(record)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-[#1E5F74] hover:bg-[#184d5e] rounded-lg transition-colors cursor-pointer shadow-2xs"
                            >
                              <span>View results</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <>
                              <button
                                onClick={() => onLaunchParentMode(record)}
                                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-[#1E5F74] bg-[#1E5F74]/10 hover:bg-[#1E5F74]/20 rounded-lg transition-colors cursor-pointer"
                                title="Hand over device to parent to answer"
                              >
                                <UserCheck className="w-3.5 h-3.5" />
                                <span>Hand to parent</span>
                              </button>
                              <button
                                onClick={() => onSelectAssessment(record)}
                                className="px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                              >
                                Draft report
                              </button>
                            </>
                          )}

                          <button
                            onClick={() => {
                              if (confirm(`Delete assessment record for ${record.childId}? (India DPDP Act right to erasure)`)) {
                                onDeleteAssessment(record.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Delete record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-10 text-center space-y-3 bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
            <p className="text-sm text-slate-500">
              {searchTerm || statusFilter !== 'all'
                ? 'No assessments found matching your filter.'
                : 'No assessments created yet.'}
            </p>
            <button
              onClick={onOpenNewAssessmentModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#1E5F74] text-white text-xs font-semibold rounded-xl cursor-pointer hover:bg-[#184d5e] transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Create first assessment</span>
            </button>
          </div>
        )}
      </div>

      {/* Counsellor Settings Modal */}
      {isSettingsOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
        >
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-md w-full p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-base font-serif font-bold text-slate-900">
                Counsellor Settings
              </h2>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-semibold"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Access Passcode (PIN)
                </label>
                <input
                  type="text"
                  required
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="e.g. 1234"
                  className="w-full h-10 px-3 font-mono font-bold bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Protects clinician screens from parents completing questionnaires.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Clinician / Counsellor Name
                </label>
                <input
                  type="text"
                  value={counsellorNameInput}
                  onChange={(e) => setCounsellorNameInput(e.target.value)}
                  placeholder="e.g. School Counsellor"
                  className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  School / Organization Name
                </label>
                <input
                  type="text"
                  value={schoolNameInput}
                  onChange={(e) => setSchoolNameInput(e.target.value)}
                  placeholder="e.g. St. Xavier’s Student Support"
                  className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
                />
              </div>

              {settingsSaved && (
                <p className="text-xs text-emerald-700 font-semibold">
                  Settings saved successfully!
                </p>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsSettingsOpen(false)}
                  className="px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-[#1E5F74] hover:bg-[#184d5e] rounded-lg cursor-pointer"
                >
                  Save settings
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
