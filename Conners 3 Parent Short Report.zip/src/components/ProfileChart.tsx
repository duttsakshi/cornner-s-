import React from 'react';
import { ScoreReportScale } from '../scoringEngine';

interface ProfileChartProps {
  scales: ScoreReportScale[];
  hasNorms: boolean;
}

export const ProfileChart: React.FC<ProfileChartProps> = ({ scales, hasNorms }) => {
  // Chart dimensions
  const svgWidth = 840;
  const svgHeight = 440;
  const margin = { top: 40, right: 170, bottom: 65, left: 60 };

  const plotWidth = svgWidth - margin.left - margin.right;
  const plotHeight = svgHeight - margin.top - margin.bottom;

  // Y Scale: 40 to 90
  const minY = 40;
  const maxY = 90;
  const getY = (t: number) => {
    const clamped = Math.min(maxY, Math.max(minY, t));
    const ratio = (clamped - minY) / (maxY - minY);
    return margin.top + (1 - ratio) * plotHeight;
  };

  // X Scale: 6 scale columns
  const numScales = scales.length;
  const getX = (index: number) => {
    return margin.left + (index + 0.5) * (plotWidth / numScales);
  };

  // Background band coordinates
  // Band 4: 70 to 90 (Much higher than most)
  const y70 = getY(70);
  const y90 = getY(90);
  const band4Height = y70 - y90;

  // Band 3: 65 to 70 (Higher than most)
  const y65 = getY(65);
  const band3Height = y65 - y70;

  // Band 2: 60 to 65 (Somewhat higher)
  const y60 = getY(60);
  const band2Height = y60 - y65;

  // Band 1: 40 to 60 (Typical range)
  const y40 = getY(40);
  const band1Height = y40 - y60;

  const y50 = getY(50);

  // Line points
  const validPoints = scales
    .map((s, idx) => ({
      scale: s,
      x: getX(idx),
      y: s.tScore !== null ? getY(s.tScore) : null,
      t: s.tScore,
      display: s.tScoreDisplay,
    }))
    .filter((p) => p.y !== null) as { scale: ScoreReportScale; x: number; y: number; t: number; display: string }[];

  const linePath = validPoints.reduce((acc, curr, idx) => {
    return idx === 0 ? `M ${curr.x} ${curr.y}` : `${acc} L ${curr.x} ${curr.y}`;
  }, '');

  return (
    <div className="w-full overflow-x-auto bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-base font-semibold text-slate-900">Scale Profile Chart</h3>
          <p className="text-xs text-slate-500">Standardized T-scores (Mean = 50, SD = 10)</p>
        </div>
        {!hasNorms && (
          <span className="text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-md">
            T-scores unavailable (norm table not checked for this group)
          </span>
        )}
      </div>

      <div className="min-w-[700px]">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-auto select-none"
          role="img"
          aria-label="Profile chart showing T-scores across six content scales"
        >
          {/* Background Bands (monochromatic calm teal, darker as scores rise) */}
          {/* Band 4: 70–90 Much higher than most */}
          <rect
            x={margin.left}
            y={y90}
            width={plotWidth}
            height={band4Height}
            fill="#A9C6D0"
            opacity="0.65"
          />
          {/* Band 3: 65–70 Higher than most */}
          <rect
            x={margin.left}
            y={y70}
            width={plotWidth}
            height={band3Height}
            fill="#C9DDE3"
            opacity="0.75"
          />
          {/* Band 2: 60–65 Somewhat higher */}
          <rect
            x={margin.left}
            y={y65}
            width={plotWidth}
            height={band2Height}
            fill="#E4EEF1"
            opacity="0.85"
          />
          {/* Band 1: 40–60 Typical range */}
          <rect
            x={margin.left}
            y={y60}
            width={plotWidth}
            height={band1Height}
            fill="#FFFFFF"
          />

          {/* Grid lines for 40, 50, 60, 65, 70, 80, 90 */}
          {[40, 60, 65, 70, 80, 90].map((t) => (
            <line
              key={t}
              x1={margin.left}
              y1={getY(t)}
              x2={margin.left + plotWidth}
              y2={getY(t)}
              stroke="#CBD5E1"
              strokeDasharray={t === 40 || t === 90 ? 'none' : '3 3'}
              strokeWidth={1}
            />
          ))}

          {/* Solid 50 Mean Baseline */}
          <line
            x1={margin.left}
            y1={y50}
            x2={margin.left + plotWidth}
            y2={y50}
            stroke="#1E5F74"
            strokeWidth={1.75}
          />

          {/* Y Axis Tick Marks and Numbers */}
          {[40, 50, 60, 65, 70, 80, 90].map((t) => (
            <g key={`tick-${t}`}>
              <text
                x={margin.left - 12}
                y={getY(t) + 4}
                textAnchor="end"
                className="text-[12px] font-sans font-medium tabular-nums fill-slate-600"
              >
                {t === 90 ? '90+' : t === 40 ? '≤40' : t}
              </text>
              <line
                x1={margin.left - 6}
                y1={getY(t)}
                x2={margin.left}
                y2={getY(t)}
                stroke="#94A3B8"
                strokeWidth={1}
              />
            </g>
          ))}

          {/* Y Axis Label */}
          <text
            transform={`rotate(-90)`}
            x={-(margin.top + plotHeight / 2)}
            y={18}
            textAnchor="middle"
            className="text-[11px] font-medium tracking-wide uppercase fill-slate-500 font-sans"
          >
            T-Score
          </text>

          {/* Right-Side Descriptive Band Labels */}
          {/* Much higher than most (70–90) */}
          <text
            x={margin.left + plotWidth + 12}
            y={y90 + band4Height / 2 + 4}
            className="text-[11px] font-medium fill-slate-700 font-sans"
          >
            Much higher than most (70+)
          </text>

          {/* Higher than most (65–69) */}
          <text
            x={margin.left + plotWidth + 12}
            y={y70 + band3Height / 2 + 4}
            className="text-[11px] font-medium fill-slate-700 font-sans"
          >
            Higher than most (65–69)
          </text>

          {/* Somewhat higher (60–64) */}
          <text
            x={margin.left + plotWidth + 12}
            y={y65 + band2Height / 2 + 4}
            className="text-[11px] font-medium fill-slate-700 font-sans"
          >
            Somewhat higher (60–64)
          </text>

          {/* Typical range (40–59) */}
          <text
            x={margin.left + plotWidth + 12}
            y={y60 + band1Height / 2 + 4}
            className="text-[11px] font-medium fill-slate-600 font-sans"
          >
            Typical range (40–59)
          </text>

          {/* Baseline annotation on right */}
          <text
            x={margin.left + plotWidth + 12}
            y={y50 + 4}
            className="text-[10px] font-bold fill-[#1E5F74] font-sans"
          >
            Baseline Mean (50)
          </text>

          {/* Connecting Line between valid points */}
          {linePath && (
            <path
              d={linePath}
              fill="none"
              stroke="#1E5F74"
              strokeWidth={2.5}
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          )}

          {/* Data Points & Column Labels */}
          {scales.map((s, idx) => {
            const x = getX(idx);
            const hasScore = s.tScore !== null;
            const y = hasScore ? getY(s.tScore!) : null;

            return (
              <g key={s.code}>
                {/* Vertical column guide */}
                <line
                  x1={x}
                  y1={margin.top}
                  x2={x}
                  y2={margin.top + plotHeight}
                  stroke="#E2E8F0"
                  strokeDasharray="2 2"
                  strokeWidth={1}
                />

                {hasScore && y !== null ? (
                  <>
                    {/* Shadow / Halo */}
                    <circle cx={x} cy={y} r={7} fill="#FFFFFF" stroke="#1E5F74" strokeWidth={2.5} />
                    <circle cx={x} cy={y} r={3.5} fill="#1E5F74" />

                    {/* T-Score text above point */}
                    <rect
                      x={x - 16}
                      y={y - 25}
                      width={32}
                      height={18}
                      rx={4}
                      fill="#1E5F74"
                    />
                    <text
                      x={x}
                      y={y - 12}
                      textAnchor="middle"
                      className="text-[11px] font-bold fill-white font-sans tabular-nums"
                    >
                      {s.tScoreDisplay}
                    </text>
                  </>
                ) : (
                  /* No Norms indicator */
                  <g>
                    <rect
                      x={x - 30}
                      y={y50 - 12}
                      width={60}
                      height={24}
                      rx={4}
                      fill="#F1F5F9"
                      stroke="#CBD5E1"
                      strokeWidth={1}
                    />
                    <text
                      x={x}
                      y={y50 + 4}
                      textAnchor="middle"
                      className="text-[11px] font-medium fill-slate-500 font-sans italic"
                    >
                      no norms
                    </text>
                  </g>
                )}

                {/* Scale Code and Scale Name below chart */}
                <text
                  x={x}
                  y={margin.top + plotHeight + 22}
                  textAnchor="middle"
                  className="text-[13px] font-bold fill-slate-900 font-sans"
                >
                  {s.code}
                </text>
                <text
                  x={x}
                  y={margin.top + plotHeight + 38}
                  textAnchor="middle"
                  className="text-[10.5px] fill-slate-500 font-sans"
                >
                  {s.name}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
};
