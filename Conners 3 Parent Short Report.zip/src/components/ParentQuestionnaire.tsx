import React, { useState, useEffect, useRef } from 'react';
import {
  ITEMS,
  RESPONSE_OPTIONS,
  TIME_FRAME_PROMPT,
  OPEN_QUESTIONS,
  DPDP_CONSENT_STATEMENT,
  STANDARD_TEST_INSTRUCTIONS,
} from '../connersConfig';
import { AssessmentRecord } from '../storage';
import {
  ChevronLeft,
  ArrowRight,
  CheckCircle2,
  Lock,
  HelpCircle,
  BookOpen,
  X,
  Send,
  Info,
} from 'lucide-react';

interface ParentQuestionnaireProps {
  assessment: AssessmentRecord;
  onUpdateAnswers: (answers: Record<number, number>, openAnswers: Record<number, string>) => void;
  onComplete: () => void;
  onRequestCounsellorAccess: () => void;
}

type ScreenMode = 'intro' | 'questions' | 'review' | 'thank_you';

export const ParentQuestionnaire: React.FC<ParentQuestionnaireProps> = ({
  assessment,
  onUpdateAnswers,
  onComplete,
  onRequestCounsellorAccess,
}) => {
  // Determine initial screen mode
  const [mode, setMode] = useState<ScreenMode>(() => {
    if (assessment.status === 'completed') return 'thank_you';
    const answeredCount = Object.keys(assessment.answers || {}).length;
    return answeredCount > 0 ? 'questions' : 'intro';
  });

  // Current item index: 0 to 42 (representing items 1 to 43)
  const [currentIndex, setCurrentIndex] = useState<number>(() => {
    const answers = assessment.answers || {};
    // Jump to first unanswered item or item 0
    for (let i = 0; i < ITEMS.length; i++) {
      if (answers[ITEMS[i].id] === undefined) return i;
    }
    return 0;
  });

  const [answers, setAnswers] = useState<Record<number, number>>(assessment.answers || {});
  const [openAnswers, setOpenAnswers] = useState<Record<number, string>>(assessment.openAnswers || {});
  const [selectedInCurrentScreen, setSelectedInCurrentScreen] = useState<number | null>(null);
  const [showInstructionsModal, setShowInstructionsModal] = useState<boolean>(false);
  const timerRef = useRef<number | null>(null);

  // Sync selected state when moving between questions
  useEffect(() => {
    const currentItemId = ITEMS[currentIndex]?.id;
    if (currentItemId !== undefined && answers[currentItemId] !== undefined) {
      setSelectedInCurrentScreen(answers[currentItemId]);
    } else {
      setSelectedInCurrentScreen(null);
    }
  }, [currentIndex, answers]);

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  const totalAnswered = Object.keys(answers).length;
  const isAllAnswered = totalAnswered === ITEMS.length;
  const progressPercent = Math.round((totalAnswered / ITEMS.length) * 100);

  const handleSelectOption = (value: number) => {
    const currentItem = ITEMS[currentIndex];
    setSelectedInCurrentScreen(value);

    const updated = {
      ...answers,
      [currentItem.id]: value,
    };
    setAnswers(updated);
    onUpdateAnswers(updated, openAnswers);

    // Auto-advance after 200ms
    if (timerRef.current) window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => {
      if (currentIndex < ITEMS.length - 1) {
        setCurrentIndex((prev) => prev + 1);
      } else {
        setMode('review');
      }
    }, 200);
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    } else {
      setMode('intro');
    }
  };

  const handleSkip = () => {
    if (currentIndex < ITEMS.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setMode('review');
    }
  };

  const handleGoToReviewOrSubmit = () => {
    setMode('review');
  };

  const handleOpenAnswerChange = (id: number, text: string) => {
    const updated = {
      ...openAnswers,
      [id]: text,
    };
    setOpenAnswers(updated);
    onUpdateAnswers(answers, updated);
  };

  const handleSubmit = () => {
    if (totalAnswered < ITEMS.length) return;
    onComplete();
    setMode('thank_you');
  };

  const unansweredItemIndices: number[] = [];
  ITEMS.forEach((item, idx) => {
    if (answers[item.id] === undefined) {
      unansweredItemIndices.push(idx);
    }
  });

  // Render dots for frequency representation
  const renderDots = (count: number) => {
    return (
      <div className="flex items-center gap-1.5" aria-hidden="true">
        {[0, 1, 2].map((dotIndex) => {
          const isFilled = dotIndex < count;
          return (
            <span
              key={dotIndex}
              className={`w-2.5 h-2.5 rounded-full transition-colors ${
                isFilled
                  ? 'bg-[#1E5F74]'
                  : 'bg-slate-200 border border-slate-300'
              }`}
            />
          );
        })}
      </div>
    );
  };

  // STANDARD INSTRUCTIONS MODAL
  const renderInstructionsModal = () => {
    if (!showInstructionsModal) return null;
    return (
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="instructions-modal-title"
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
      >
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#1E5F74]" />
              <h3 id="instructions-modal-title" className="font-serif font-bold text-slate-900 text-lg">
                {STANDARD_TEST_INSTRUCTIONS.title}
              </h3>
            </div>
            <button
              onClick={() => setShowInstructionsModal(false)}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Close instructions"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-4 text-sm text-slate-700 leading-relaxed">
            <p className="font-medium text-slate-900 bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
              {STANDARD_TEST_INSTRUCTIONS.lead}
            </p>

            <div className="space-y-2">
              <h4 className="font-semibold text-xs text-slate-500 uppercase tracking-wider">
                Guidelines for rating:
              </h4>
              <ul className="space-y-2 list-disc list-inside text-slate-700 text-xs sm:text-sm pl-1">
                {STANDARD_TEST_INSTRUCTIONS.steps.map((step, idx) => (
                  <li key={idx}>{step}</li>
                ))}
              </ul>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100">
              <h4 className="font-semibold text-xs text-slate-500 uppercase tracking-wider">
                {STANDARD_TEST_INSTRUCTIONS.optionsIntro}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {RESPONSE_OPTIONS.map((opt) => (
                  <div key={opt.value} className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                    <div className="font-bold text-slate-900">{opt.value} — {opt.label}</div>
                    <div className="text-slate-500">{opt.subLabel}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-1.5 pt-2 border-t border-slate-100 text-xs text-slate-500">
              {STANDARD_TEST_INSTRUCTIONS.importantNotes.map((note, idx) => (
                <p key={idx}>• {note}</p>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              onClick={() => setShowInstructionsModal(false)}
              className="px-5 py-2 text-xs font-semibold text-white bg-[#1E5F74] hover:bg-[#184d5e] rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Close & Resume Questionnaire
            </button>
          </div>
        </div>
      </div>
    );
  };

  // SCREEN 1: INTRO (Contains full standard instructions)
  if (mode === 'intro') {
    return (
      <main className="min-h-[85vh] flex flex-col justify-between max-w-xl mx-auto p-4 sm:p-8">
        <div className="space-y-5 pt-2 sm:pt-4">
          <header className="space-y-1.5">
            <span className="text-xs font-semibold tracking-wider uppercase text-[#1E5F74]">
              Parent Questionnaire · Administration
            </span>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 tracking-tight">
              Child Behaviour Observations
            </h1>
          </header>

          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4 text-slate-700 text-sm sm:text-base leading-relaxed">
            {/* Standard Instruction Lead */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5">
              <div className="flex items-center gap-2 text-[#1E5F74] font-semibold text-xs uppercase tracking-wider">
                <BookOpen className="w-4 h-4" />
                <span>{STANDARD_TEST_INSTRUCTIONS.title}</span>
              </div>
              <p className="text-slate-800 font-medium text-sm sm:text-base leading-snug">
                {STANDARD_TEST_INSTRUCTIONS.lead}
              </p>
            </div>

            {/* Standard Steps / Guidelines */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                How to complete this questionnaire:
              </span>
              <ul className="space-y-1.5 text-xs sm:text-sm text-slate-700 pl-1">
                {STANDARD_TEST_INSTRUCTIONS.steps.map((step, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#1E5F74] mt-2 shrink-0" />
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* 4 Response Options with Dot Indicators */}
            <div className="pt-2 border-t border-slate-100">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-2.5">
                {STANDARD_TEST_INSTRUCTIONS.optionsIntro}
              </span>
              <div className="space-y-2">
                {RESPONSE_OPTIONS.map((opt) => (
                  <div
                    key={opt.value}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50/80 border border-slate-200/80"
                  >
                    <div>
                      <span className="font-semibold text-slate-800 text-sm block">
                        {opt.value} — {opt.label}
                      </span>
                      <span className="text-xs text-slate-500">{opt.subLabel}</span>
                    </div>
                    {renderDots(opt.dots)}
                  </div>
                ))}
              </div>
            </div>

            {/* Notes & Privacy */}
            <div className="pt-3 border-t border-slate-100 space-y-2 text-xs text-slate-500 leading-normal">
              <p>
                Takes about <strong>5 to 10 minutes</strong>. You can skip any question and return to it later.
              </p>
              <p>{DPDP_CONSENT_STATEMENT}</p>
            </div>
          </div>
        </div>

        <div className="py-6">
          <button
            onClick={() => setMode('questions')}
            className="w-full h-14 bg-[#1E5F74] hover:bg-[#184d5e] active:scale-[0.99] text-white font-semibold text-lg rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer focus:outline-none focus:ring-3 focus:ring-[#E3A13A]"
          >
            <span>Begin questionnaire</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </main>
    );
  }

  // SCREEN 4: THANK YOU SCREEN
  if (mode === 'thank_you') {
    return (
      <main className="min-h-[85vh] flex flex-col items-center justify-center max-w-md mx-auto p-6 text-center space-y-8">
        <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 mx-auto">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div className="space-y-3">
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900">
            Thank You
          </h1>
          <p className="text-base text-slate-600 leading-relaxed">
            Your responses have been saved securely.
          </p>
          <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs text-slate-800 font-medium">
            Please hand the device back to the counsellor.
          </div>
        </div>

        <div className="pt-8">
          <button
            onClick={onRequestCounsellorAccess}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 px-3 py-2 rounded-lg transition-colors cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Open Counsellor View</span>
          </button>
        </div>
      </main>
    );
  }

  // SCREEN 3: REVIEW SCREEN
  if (mode === 'review') {
    return (
      <main className="min-h-[85vh] max-w-xl mx-auto p-5 sm:p-8 space-y-6 pb-20">
        <header className="space-y-1">
          <span className="text-xs font-semibold tracking-wider uppercase text-[#1E5F74]">
            Review & Finish
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900">
            Review Your Responses
          </h1>
          <p className="text-sm text-slate-600">
            {isAllAnswered
              ? 'All 43 statements have been answered.'
              : `${unansweredItemIndices.length} statement${unansweredItemIndices.length === 1 ? '' : 's'} still need an answer.`}
          </p>
        </header>

        {/* Unanswered items list */}
        {!isAllAnswered && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 space-y-3">
            <div className="flex items-center gap-2 text-amber-900 font-semibold text-sm">
              <HelpCircle className="w-4 h-4 text-amber-700" />
              <span>Unanswered questions (tap to answer):</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {unansweredItemIndices.map((idx) => {
                const itemNum = ITEMS[idx].id;
                return (
                  <button
                    key={itemNum}
                    onClick={() => {
                      setCurrentIndex(idx);
                      setMode('questions');
                    }}
                    className="px-3 py-1.5 bg-white hover:bg-amber-100 border border-amber-300 rounded-lg text-xs font-semibold text-amber-900 transition-colors cursor-pointer shadow-xs"
                  >
                    Question #{itemNum}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Open-ended Questions */}
        <div className="space-y-5 pt-2">
          <h2 className="text-lg font-serif font-bold text-slate-900 border-b border-slate-200 pb-2">
            Additional Thoughts (Optional)
          </h2>

          {OPEN_QUESTIONS.map((q) => (
            <div key={q.id} className="space-y-2">
              <label
                htmlFor={`open-q-${q.id}`}
                className="block text-sm font-semibold text-slate-800"
              >
                {q.id}. {q.text}
              </label>
              <textarea
                id={`open-q-${q.id}`}
                rows={3}
                value={openAnswers[q.id] || ''}
                onChange={(e) => handleOpenAnswerChange(q.id, e.target.value)}
                placeholder={q.placeholder}
                className="w-full p-3.5 rounded-xl bg-white border border-slate-300 text-slate-900 text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-[#1E5F74] focus:border-transparent transition-all placeholder:text-slate-400"
              />
            </div>
          ))}
        </div>

        {/* Submission area */}
        <div className="pt-6 border-t border-slate-200 space-y-3">
          <button
            onClick={handleSubmit}
            disabled={!isAllAnswered}
            className={`w-full h-14 font-semibold text-base rounded-xl transition-all flex items-center justify-center gap-2 ${
              isAllAnswered
                ? 'bg-[#1E5F74] hover:bg-[#184d5e] text-white shadow-md cursor-pointer focus:ring-3 focus:ring-[#E3A13A]'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <span>Submit answers</span>
            <CheckCircle2 className="w-5 h-5" />
          </button>

          {!isAllAnswered && (
            <p className="text-xs text-center text-rose-700 font-medium">
              Every item must be answered before submission. Please tap the unanswered items above.
            </p>
          )}

          <div className="flex justify-center pt-2">
            <button
              onClick={() => {
                setCurrentIndex(0);
                setMode('questions');
              }}
              className="text-xs text-slate-600 hover:text-slate-900 py-2 px-3 rounded-md cursor-pointer transition-colors"
            >
              Return to first statement
            </button>
          </div>
        </div>
      </main>
    );
  }

  // SCREEN 2: QUESTION SCREEN (Fixed layout, stable controls, Skip & Submit)
  const currentItem = ITEMS[currentIndex];

  return (
    <main className="min-h-screen flex flex-col justify-between max-w-xl mx-auto">
      {renderInstructionsModal()}

      {/* 1. Sticky Header */}
      <header className="sticky top-0 z-20 bg-[#EEF3F4]/95 backdrop-blur-md px-4 sm:px-6 pt-3 pb-2.5 border-b border-slate-200/80">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-600 mb-1.5">
          <span className="text-[#1E5F74] font-medium">{TIME_FRAME_PROMPT}</span>

          <div className="flex items-center gap-2">
            {/* Standard Instructions Button */}
            <button
              type="button"
              onClick={() => setShowInstructionsModal(true)}
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#1E5F74] hover:text-[#184d5e] bg-white hover:bg-slate-100 px-2 py-0.5 rounded border border-slate-200 transition-colors cursor-pointer"
              title="View standard test instructions"
            >
              <Info className="w-3 h-3" />
              <span>Instructions</span>
            </button>

            <span className="tabular-nums font-mono text-slate-700">
              {totalAnswered} of 43 answered
            </span>
          </div>
        </div>

        {/* Progress Bar in Marigold */}
        <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#E3A13A] transition-all duration-300 ease-out rounded-full"
            style={{ width: `${Math.max(4, progressPercent)}%` }}
          />
        </div>

        {/* Activated All Answered Alert Banner */}
        {isAllAnswered && (
          <div className="mt-2 p-2 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between animate-in fade-in">
            <span className="text-xs font-semibold text-emerald-800 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              All 43 statements answered!
            </span>
            <button
              onClick={handleGoToReviewOrSubmit}
              className="px-3 py-1 bg-[#1E5F74] hover:bg-[#184d5e] text-white text-xs font-bold rounded-md shadow-xs transition-colors cursor-pointer flex items-center gap-1"
            >
              <span>Submit answers</span>
              <Send className="w-3 h-3" />
            </button>
          </div>
        )}
      </header>

      {/* 2. Main Question Card Area with FIXED HEIGHT to guarantee ZERO layout shifts */}
      <div className="flex-1 flex flex-col justify-start px-4 sm:px-6 pt-5 pb-4 space-y-4">
        {/* Fixed height statement container so 1-line or 3-line statements never move the layout */}
        <div className="min-h-[115px] sm:min-h-[125px] flex flex-col justify-start">
          <span className="text-xs font-bold font-mono tracking-wider text-slate-500 uppercase block mb-1">
            Statement {currentIndex + 1} of 43
          </span>
          <h2 className="text-xl sm:text-2xl font-serif font-medium text-slate-900 leading-snug">
            {currentItem.text}
          </h2>
        </div>

        {/* 4 Full-Width Answer Buttons: exact fixed height (72px) so options block layout NEVER shifts */}
        <div className="space-y-3">
          {RESPONSE_OPTIONS.map((opt) => {
            const isSelected = selectedInCurrentScreen === opt.value;
            return (
              <button
                key={opt.value}
                onClick={() => handleSelectOption(opt.value)}
                className={`w-full h-[72px] sm:h-[76px] px-4 rounded-2xl text-left border-2 transition-all flex items-center justify-between cursor-pointer focus:outline-none focus:ring-3 focus:ring-[#E3A13A] select-none ${
                  isSelected
                    ? 'border-[#1E5F74] bg-[#1E5F74]/10 shadow-xs'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/80 shadow-2xs'
                }`}
              >
                <div className="space-y-0.5">
                  <div
                    className={`font-semibold text-base sm:text-lg leading-tight ${
                      isSelected ? 'text-[#1E5F74]' : 'text-slate-900'
                    }`}
                  >
                    {opt.label}
                  </div>
                  <div className="text-xs text-slate-500 font-normal">
                    {opt.subLabel}
                  </div>
                </div>

                {/* Dot Indicator */}
                <div className="ml-3 shrink-0">
                  {renderDots(opt.dots)}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Pinned Sticky Bottom Navigation Bar */}
      {/*
          Fixed layout guarantees:
          - "Skip for now" is ALWAYS at the exact same physical coordinates on every single item.
          - "Submit answers" button becomes actively lit up when all 43 are answered so you don't have to keep clicking skip.
      */}
      <footer className="sticky bottom-0 z-20 bg-[#EEF3F4]/98 backdrop-blur-md border-t border-slate-200/90 py-3.5 px-4 sm:px-6">
        <div className="grid grid-cols-3 items-center gap-2">
          {/* Col 1 (Left): Back Button */}
          <div className="flex justify-start">
            <button
              onClick={handlePrevious}
              className="inline-flex items-center gap-1 py-2 px-3 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 rounded-lg transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          </div>

          {/* Col 2 (Center): "Skip for now" Option - EXACT FIXED POSITION ON EVERY ITEM */}
          <div className="flex justify-center">
            <button
              onClick={handleSkip}
              className="py-2 px-4 text-xs font-medium text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              Skip for now
            </button>
          </div>

          {/* Col 3 (Right): Submit Option - ACTIVATED when all 43 questions are answered */}
          <div className="flex justify-end">
            {isAllAnswered ? (
              <button
                onClick={handleGoToReviewOrSubmit}
                className="inline-flex items-center gap-1.5 py-2 px-3 text-xs font-bold text-white bg-[#1E5F74] hover:bg-[#184d5e] active:scale-[0.98] rounded-xl shadow-xs transition-all cursor-pointer ring-2 ring-emerald-400"
                title="All 43 answered - click to submit"
              >
                <span>Submit</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
              </button>
            ) : (
              <button
                onClick={handleGoToReviewOrSubmit}
                className="inline-flex items-center gap-1 py-2 px-2.5 text-[11px] font-medium text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                title="Jump to review overview"
              >
                <span>Review ({totalAnswered}/43)</span>
              </button>
            )}
          </div>
        </div>
      </footer>
    </main>
  );
};
