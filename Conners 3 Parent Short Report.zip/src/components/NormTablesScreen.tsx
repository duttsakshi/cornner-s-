import React, { useState, useMemo, useRef } from 'react';
import {
  Sex,
  ScaleCode,
  SCALE_CODES,
  CONTENT_SCALES,
  VALID_AGES,
  AllNormTables,
  NormTableData,
  validateNormTable,
  getNormGroupKey,
  createDefaultNormTable,
} from '../connersConfig';
import {
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Download,
  Upload,
  RotateCcw,
  ShieldCheck,
  FileCheck,
} from 'lucide-react';

interface NormTablesScreenProps {
  norms: AllNormTables;
  onSaveNorms: (updatedNorms: AllNormTables) => void;
  onBack: () => void;
}

export const NormTablesScreen: React.FC<NormTablesScreenProps> = ({
  norms,
  onSaveNorms,
  onBack,
}) => {
  const [selectedSex, setSelectedSex] = useState<Sex>('F');
  const [selectedAge, setSelectedAge] = useState<number>(9);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const groupKey = getNormGroupKey(selectedSex, selectedAge);

  // Ensure this group's table exists in local state
  const currentTable: NormTableData = useMemo(() => {
    if (norms[groupKey]) {
      return norms[groupKey];
    }
    return createDefaultNormTable('draft');
  }, [norms, groupKey]);

  // Run automatic validation checks on the active table
  const validationResult = useMemo(() => {
    return validateNormTable(currentTable);
  }, [currentTable]);

  // Set of invalid cell keys: `${scale}-${raw}`
  const invalidCellMap = useMemo(() => {
    const map = new Map<string, string>();
    for (const err of validationResult.errors) {
      map.set(`${err.scale}-${err.raw}`, err.message);
    }
    return map;
  }, [validationResult]);

  const handleCellChange = (scale: ScaleCode, raw: number, valueStr: string) => {
    const val = valueStr === '' ? NaN : parseInt(valueStr, 10);
    const updatedScaleValues = [...(currentTable[scale] || [])];
    updatedScaleValues[raw] = isNaN(val) ? (undefined as unknown as number) : val;

    const updatedTable: NormTableData = {
      ...currentTable,
      [scale]: updatedScaleValues,
      status: 'draft', // editing shifts status to draft until re-checked
    };

    const updatedAllNorms: AllNormTables = {
      ...norms,
      [groupKey]: updatedTable,
    };

    onSaveNorms(updatedAllNorms);
  };

  const handleMarkAsChecked = () => {
    if (!validationResult.isValid) return;

    const updatedTable: NormTableData = {
      ...currentTable,
      status: 'ready',
      lastCheckedDate: new Date().toISOString().split('T')[0],
      checkedBy: 'Clinician Verification',
    };

    const updatedAllNorms: AllNormTables = {
      ...norms,
      [groupKey]: updatedTable,
    };

    onSaveNorms(updatedAllNorms);
    setFeedbackMessage(`Norm table for ${selectedSex === 'F' ? 'Girls' : 'Boys'} (Group ${groupKey}) successfully verified and marked ready.`);
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  const handleUnmarkChecked = () => {
    const updatedTable: NormTableData = {
      ...currentTable,
      status: 'draft',
    };

    const updatedAllNorms: AllNormTables = {
      ...norms,
      [groupKey]: updatedTable,
    };

    onSaveNorms(updatedAllNorms);
    setFeedbackMessage(`Group ${groupKey} set to draft mode.`);
    setTimeout(() => setFeedbackMessage(null), 3000);
  };

  const handleResetCurrentToDefault = () => {
    if (confirm(`Reset group ${groupKey} to standard baseline profile data?`)) {
      const updatedAllNorms: AllNormTables = {
        ...norms,
        [groupKey]: createDefaultNormTable('ready'),
      };
      onSaveNorms(updatedAllNorms);
      setFeedbackMessage(`Group ${groupKey} restored to standard profile.`);
      setTimeout(() => setFeedbackMessage(null), 3000);
    }
  };

  // Backup all norm tables as JSON
  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(norms, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `conners3_norm_tables_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Restore norm tables from JSON
  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], 'UTF-8');
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (typeof parsed === 'object' && parsed !== null) {
            onSaveNorms(parsed);
            setFeedbackMessage('Norm tables successfully restored from JSON file.');
            setTimeout(() => setFeedbackMessage(null), 4000);
          } else {
            alert('Invalid JSON file format.');
          }
        } catch (err) {
          alert('Failed to parse JSON file.');
        }
      };
    }
  };

  // Summary counts
  const totalGroups = 24;
  const verifiedCount = Object.values(norms).filter((t) => t && t.status === 'ready').length;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to assessments</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportJson}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            title="Export all 24 norm groups as JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Backup JSON</span>
          </button>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImportJson}
            accept=".json"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            title="Import norm tables from JSON backup"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Restore JSON</span>
          </button>
        </div>
      </div>

      {feedbackMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-sm font-medium flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedbackMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div>
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-serif font-bold text-slate-900">
              Norm Tables Management
            </h1>
            <span className="text-xs font-medium text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md">
              {verifiedCount} of {totalGroups} groups verified
            </span>
          </div>
          <p className="text-sm text-slate-600 mt-1">
            Official profile sheet conversion tables. Raw scores (0–18) are converted to standardized T-scores.
            T-scores are only applied if marked verified.
          </p>
        </div>

        {/* Group Selector Controls */}
        <div className="p-4 bg-[#EEF3F4]/70 rounded-xl border border-slate-200/80 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Sex Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                Biological Sex
              </label>
              <div className="flex items-center gap-1 p-1 bg-white rounded-lg border border-slate-200">
                <button
                  type="button"
                  onClick={() => setSelectedSex('F')}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    selectedSex === 'F'
                      ? 'bg-[#1E5F74] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Female (Girls)
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedSex('M')}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    selectedSex === 'M'
                      ? 'bg-[#1E5F74] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Male (Boys)
                </button>
              </div>
            </div>

            {/* Age Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                Norm Age Group
              </label>
              <select
                value={selectedAge}
                onChange={(e) => setSelectedAge(parseInt(e.target.value, 10))}
                className="w-full h-9 px-3 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1E5F74] cursor-pointer"
              >
                {VALID_AGES.map((age) => (
                  <option key={age} value={age}>
                    {age === 17 ? 'Ages 17–18 (Group 17)' : `Age ${age} (Group ${age})`}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Group Status & Verification Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
            <div className="flex items-center gap-2 text-sm">
              <span className="font-bold text-slate-800">Group Key: {groupKey}</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span
                className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-0.5 rounded-full ${
                  currentTable.status === 'ready'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {currentTable.status === 'ready' ? (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Checked & Ready</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>Draft (Unchecked)</span>
                  </>
                )}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleResetCurrentToDefault}
                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 hover:bg-white rounded-md border border-transparent hover:border-slate-200 transition-colors cursor-pointer"
                title="Reset this table to standard baseline profile"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset profile</span>
              </button>

              {currentTable.status === 'ready' ? (
                <button
                  type="button"
                  onClick={handleUnmarkChecked}
                  className="px-3 py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition-colors cursor-pointer"
                >
                  Edit table
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleMarkAsChecked}
                  disabled={!validationResult.isValid}
                  className={`inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                    validationResult.isValid
                      ? 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs cursor-pointer'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>Mark as checked</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Validation Error Line */}
        <div
          className={`p-3 rounded-xl text-xs font-medium flex items-center gap-2 ${
            validationResult.isValid
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          {validationResult.isValid ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{validationResult.summaryMessage}</span>
        </div>

        {/* The 0–18 x 6 Interactive Grid */}
        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-center border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-semibold uppercase">
                <th scope="col" className="py-2.5 px-3 w-16 bg-slate-200/60">Raw</th>
                {SCALE_CODES.map((code) => {
                  const meta = CONTENT_SCALES[code];
                  return (
                    <th scope="col" key={code} className="py-2.5 px-3 min-w-[90px]">
                      <div>{meta.name}</div>
                      <div className="text-[10px] text-slate-500 lowercase font-normal font-mono">
                        {code} (max {meta.maxRaw})
                      </div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {Array.from({ length: 19 }, (_, raw) => {
                return (
                  <tr key={raw} className="hover:bg-slate-50/70 transition-colors">
                    {/* Raw score index label */}
                    <td className="py-1 px-3 font-mono font-bold bg-slate-50 text-slate-600 border-r border-slate-200">
                      {raw}
                    </td>

                    {/* Scale cells */}
                    {SCALE_CODES.map((code) => {
                      const meta = CONTENT_SCALES[code];
                      const isBeyondMax = raw > meta.maxRaw;
                      const cellKey = `${code}-${raw}`;
                      const hasError = invalidCellMap.has(cellKey);
                      const errorMessage = invalidCellMap.get(cellKey);

                      if (isBeyondMax) {
                        return (
                          <td key={code} className="py-1 px-2 text-slate-300 bg-slate-50/40 select-none">
                            —
                          </td>
                        );
                      }

                      const currentVal = currentTable[code]?.[raw];
                      const displayVal = currentVal !== undefined && !isNaN(currentVal) ? currentVal : '';

                      return (
                        <td key={code} className="py-1 px-2 relative">
                          <input
                            type="number"
                            min={20}
                            max={90}
                            value={displayVal}
                            onChange={(e) => handleCellChange(code, raw, e.target.value)}
                            title={errorMessage || `${code} raw ${raw}`}
                            className={`w-16 h-7 text-center font-mono tabular-nums font-medium text-xs rounded border transition-colors focus:outline-none focus:ring-2 focus:ring-[#1E5F74] ${
                              hasError
                                ? 'bg-rose-50 border-rose-400 text-rose-900 ring-1 ring-rose-300'
                                : 'bg-white border-slate-200 text-slate-800 hover:border-slate-300'
                            }`}
                          />
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
