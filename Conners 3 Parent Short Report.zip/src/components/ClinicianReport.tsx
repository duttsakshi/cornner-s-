import React, { useState } from 'react';
import {
  Printer,
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  Calendar,
  User,
  Info,
  Layers,
  FileText,
} from 'lucide-react';
import { ScoredAssessmentReport } from '../scoringEngine';
import { ProfileChart } from './ProfileChart';
import { FOOTER_DISCLAIMER, CONTENT_SCALES, AnyScaleCode } from '../connersConfig';

interface ClinicianReportProps {
  report: ScoredAssessmentReport;
  onBackToDashboard: () => void;
  onReturnToParentMode?: () => void;
}

export const ClinicianReport: React.FC<ClinicianReportProps> = ({
  report,
  onBackToDashboard,
  onReturnToParentMode,
}) => {
  const [showItemsRated2, setShowItemsRated2] = useState<boolean>(false);
  const [showAllResponses, setShowAllResponses] = useState<boolean>(false);

  const handlePrint = () => {
    window.print();
  };

  const getValidityIcon = () => {
    switch (report.validity.overallLevel) {
      case 'consistent':
        return <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />;
      case 'possibly_raised':
        return <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />;
      case 'likely_raised':
        return <AlertCircle className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" />;
    }
  };

  const getValidityBannerStyle = () => {
    switch (report.validity.overallLevel) {
      case 'consistent':
        return 'bg-emerald-50/80 border-emerald-200 text-emerald-900';
      case 'possibly_raised':
        return 'bg-amber-50/80 border-amber-200 text-amber-900';
      case 'likely_raised':
        return 'bg-rose-50/80 border-rose-200 text-rose-900';
    }
  };

  return (
    <div className="max-w-5xl mx-auto pb-16 pt-4 px-4 sm:px-6">
      {/* Clinician Top Action Bar (hidden in print) */}
      <div className="no-print mb-6 flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
        <button
          onClick={onBackToDashboard}
          className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Assessments
        </button>

        <div className="flex items-center gap-2">
          {onReturnToParentMode && !report.isCompleted && (
            <button
              onClick={onReturnToParentMode}
              className="px-3.5 py-2 text-sm font-medium text-[#1E5F74] hover:bg-[#1E5F74]/10 rounded-lg border border-[#1E5F74]/30 transition-colors cursor-pointer"
            >
              Resume Questionnaire
            </button>
          )}

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-[#1E5F74] hover:bg-[#184d5e] rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print / Save as PDF
          </button>
        </div>
      </div>

      {/* Report Paper Surface */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-10 shadow-xs space-y-8 print-shadow-none">
        {/* Section 1: Header */}
        <header className="border-b border-slate-200 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                Conners 3 Parent Short Form · Clinician Evaluation
              </div>
              <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 tracking-tight">
                {report.childName ? `${report.childName} (${report.childId})` : report.childId}
              </h1>
            </div>
            <div className="text-right sm:text-right">
              <div className="text-xs text-slate-500">Assessment Date</div>
              <div className="text-sm font-medium text-slate-800">{report.assessmentDate}</div>
            </div>
          </div>

          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-5 pt-5 border-t border-slate-100 text-sm">
            <div>
              <span className="text-xs text-slate-500 block">Age at Assessment</span>
              <span className="font-semibold text-slate-800">{report.ageFormatted}</span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">Assigned Comparison Group</span>
              <span className="font-semibold text-slate-800">{report.comparisonGroupDisplay}</span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">Rater / Respondent</span>
              <span className="font-medium text-slate-800">{report.raterName || 'Parent / Guardian'}</span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">Grade / Class</span>
              <span className="font-medium text-slate-800">{report.grade || 'Not specified'}</span>
            </div>
          </div>

          {report.adminNote && (
            <div className="mt-4 p-3 bg-slate-50 rounded-lg text-xs text-slate-700 flex items-start gap-2 border border-slate-200/60">
              <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-800">Administration Note: </span>
                <span>{report.adminNote}</span>
              </div>
            </div>
          )}
        </header>

        {/* Section 2: Validity Banner */}
        <section aria-label="Validity Check" className="print-break-inside-avoid">
          <div className={`p-4 sm:p-5 rounded-xl border flex items-start gap-3.5 ${getValidityBannerStyle()}`}>
            {getValidityIcon()}
            <div className="space-y-1 text-sm">
              <h2 className="font-bold text-base leading-snug">{report.validity.title}</h2>
              <p className="leading-relaxed opacity-95">{report.validity.body}</p>
              <div className="pt-1.5 text-xs font-medium opacity-80">
                {report.validity.subtext}
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: Profile Chart */}
        <section aria-label="Profile Chart" className="print-break-inside-avoid">
          <ProfileChart scales={report.scaleList} hasNorms={report.hasNorms} />
        </section>

        {/* Section 4: Score Table */}
        <section aria-label="Score Summary Table" className="print-break-inside-avoid">
          <div className="mb-3">
            <h2 className="text-lg font-serif font-bold text-slate-900">Score Summary Table</h2>
            <p className="text-xs text-slate-500">
              Comparing raw scores with {report.comparisonGroupDisplay} norm reference sample.
            </p>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-100/70 border-b border-slate-200 text-xs font-semibold text-slate-700 uppercase tracking-wider">
                  <th scope="col" className="py-3 px-4">Scale</th>
                  <th scope="col" className="py-3 px-4">Items Measure</th>
                  <th scope="col" className="py-3 px-4 text-center">Raw Score</th>
                  <th scope="col" className="py-3 px-4 text-center">T-Score</th>
                  <th scope="col" className="py-3 px-4 text-center">Percentile</th>
                  <th scope="col" className="py-3 px-4">Comparison Band</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {report.scaleList.map((scale) => {
                  // Position bar width calculation (40 to 90 scale)
                  const tVal = scale.tScore ?? 40;
                  const barPercent = Math.max(0, Math.min(100, ((tVal - 40) / (90 - 40)) * 100));

                  return (
                    <tr key={scale.code} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{scale.name}</div>
                        <div className="text-xs font-mono text-slate-500">{scale.code}</div>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600 max-w-[220px]">
                        {scale.description}
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono tabular-nums text-slate-800">
                        {scale.rawScore} <span className="text-slate-400 text-xs">/ {scale.maxRaw}</span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {scale.hasNorms ? (
                          <div className="inline-flex flex-col items-center">
                            <span className="font-bold text-slate-900 font-mono tabular-nums">
                              {scale.tScoreDisplay}
                            </span>
                            <div className="w-16 h-1.5 bg-slate-200 rounded-full mt-1 overflow-hidden">
                              <div
                                className="h-full bg-[#1E5F74] rounded-full"
                                style={{ width: `${barPercent}%` }}
                              />
                            </div>
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400 italic">No norms</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-center text-xs tabular-nums text-slate-700">
                        {scale.percentile !== null ? `approx. ${scale.percentile}%` : '—'}
                      </td>
                      <td className="py-3.5 px-4 text-xs">
                        {scale.bandWording ? (
                          <span
                            className={
                              (scale.tScore ?? 0) >= 65
                                ? 'font-semibold text-slate-900'
                                : (scale.tScore ?? 0) >= 60
                                ? 'font-medium text-slate-800'
                                : 'text-slate-600'
                            }
                          >
                            {scale.bandWording}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">Unavailable</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* Section 5: Areas that may be worth exploring */}
        <section aria-label="Areas to Explore" className="p-5 bg-slate-50/70 border border-slate-200/80 rounded-xl space-y-3 print-break-inside-avoid">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#1E5F74]" />
            <h2 className="text-lg font-serif font-bold text-slate-900">
              Areas That May Be Worth Exploring
            </h2>
          </div>
          <p className="text-xs text-slate-500">
            Scales where the parent's ratings fall at or above T 60, presented in descending order of score.
          </p>

          {report.areasToExplore.length > 0 ? (
            <div className="space-y-3 pt-2">
              {report.areasToExplore.map((area) => (
                <div
                  key={area.scaleCode}
                  className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-[#1E5F74]">
                      {area.scaleName} ({area.scaleCode}) · T-Score: {area.tScore >= 90 ? '90+' : area.tScore}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">
                      approx. {area.percentile}% percentile
                    </span>
                  </div>
                  <p className="text-sm text-slate-700 leading-relaxed font-sans">
                    {area.narrative}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white p-4 rounded-lg border border-slate-200 text-sm text-slate-700 leading-relaxed">
              {report.noAreasAbove60Narrative ||
                'Standardized comparisons are unavailable because the norm table for this comparison group has not been verified.'}
            </div>
          )}
        </section>

        {/* Section 6: Statements rated "very much true" (3) and collapsible rated (2) */}
        <section aria-label="High Rating Items" className="border-t border-slate-200 pt-6 space-y-4 print-break-inside-avoid">
          <div>
            <h2 className="text-lg font-serif font-bold text-slate-900">
              Statements Rated "Very Much True" (3)
            </h2>
            <p className="text-xs text-slate-500">
              Behaviours rated as occurring very often or very frequently over the past month.
            </p>
          </div>

          {report.itemsRated3.length > 0 ? (
            <ul className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white">
              {report.itemsRated3.map((item) => (
                <li key={item.id} className="p-3.5 flex items-start justify-between gap-4 text-sm">
                  <div className="flex items-start gap-2.5">
                    <span className="font-mono text-xs font-semibold text-slate-400 mt-0.5">
                      #{item.id}
                    </span>
                    <span className="text-slate-800 font-medium">{item.text}</span>
                  </div>
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0">
                    {item.scale}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="p-4 bg-slate-50 rounded-lg text-sm text-slate-500 italic border border-slate-200/60">
              No statements were rated "Very much true" (3).
            </div>
          )}

          {/* Collapsible list of items rated 2 */}
          <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
            <button
              onClick={() => setShowItemsRated2(!showItemsRated2)}
              className="w-full p-3.5 flex items-center justify-between text-left text-sm font-semibold text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                {showItemsRated2 ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                Statements rated "Pretty much true" (2) ({report.itemsRated2.length} item{report.itemsRated2.length === 1 ? '' : 's'})
              </span>
              <span className="text-xs text-slate-500 font-normal">
                {showItemsRated2 ? 'Hide' : 'Show'}
              </span>
            </button>

            {showItemsRated2 && (
              <ul className="divide-y divide-slate-100 border-t border-slate-200 bg-slate-50/40">
                {report.itemsRated2.length > 0 ? (
                  report.itemsRated2.map((item) => (
                    <li key={item.id} className="p-3 flex items-start justify-between gap-4 text-xs">
                      <div className="flex items-start gap-2">
                        <span className="font-mono font-semibold text-slate-400">#{item.id}</span>
                        <span className="text-slate-700">{item.text}</span>
                      </div>
                      <span className="font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0">
                        {item.scale}
                      </span>
                    </li>
                  ))
                ) : (
                  <li className="p-3 text-xs text-slate-500 italic">No statements were rated 2.</li>
                )}
              </ul>
            )}
          </div>
        </section>

        {/* Section 7: In the Parent's Words */}
        <section aria-label="Open Ended Responses" className="border-t border-slate-200 pt-6 space-y-4 print-break-inside-avoid">
          <div>
            <h2 className="text-lg font-serif font-bold text-slate-900">In the Parent’s Words</h2>
            <p className="text-xs text-slate-500">
              Unedited qualitative comments submitted at the conclusion of the form.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {report.openResponses.map((q) => (
              <div key={q.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
                <h3 className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
                  {q.question}
                </h3>
                <p className="text-sm text-slate-900 italic font-serif leading-relaxed whitespace-pre-wrap">
                  "{q.answer}"
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Section 8: All 43 responses (collapsible) */}
        <section aria-label="All Responses" className="border-t border-slate-200 pt-6 no-print">
          <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
            <button
              onClick={() => setShowAllResponses(!showAllResponses)}
              className="w-full p-4 flex items-center justify-between text-left text-sm font-semibold text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                {showAllResponses ? <ChevronDown className="w-4 h-4 text-slate-600" /> : <ChevronRight className="w-4 h-4 text-slate-600" />}
                View Complete Item Responses (All 43 Items)
              </span>
              <span className="text-xs text-slate-500 font-normal">
                {showAllResponses ? 'Collapse table' : 'Expand full list'}
              </span>
            </button>

            {showAllResponses && (
              <div className="border-t border-slate-200 overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600 uppercase font-semibold">
                      <th className="py-2.5 px-4 w-12 text-center">#</th>
                      <th className="py-2.5 px-4">Statement</th>
                      <th className="py-2.5 px-4 w-16 text-center">Scale</th>
                      <th className="py-2.5 px-4 w-28 text-center">Raw Rating</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {report.allResponses.map((item) => {
                      const labels = ['0 (Not true)', '1 (Just a little)', '2 (Pretty much)', '3 (Very much)'];
                      return (
                        <tr key={item.id} className="hover:bg-slate-50">
                          <td className="py-2 px-4 text-center font-mono text-slate-400 font-medium">
                            {item.id}
                          </td>
                          <td className="py-2 px-4 text-slate-800">{item.text}</td>
                          <td className="py-2 px-4 text-center font-mono text-slate-600">
                            {item.scale}
                          </td>
                          <td className="py-2 px-4 text-center font-medium text-slate-900">
                            {labels[item.value] || item.value}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </section>

        {/* Section 9: Footer Note */}
        <footer className="border-t border-slate-200 pt-6 text-xs text-slate-500 leading-relaxed space-y-2 print-break-inside-avoid">
          <p className="font-medium text-slate-600">
            {FOOTER_DISCLAIMER}
          </p>
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-[11px] text-slate-400">
            <span>Conners 3 Parent Short (Conners 3-P (S)) Administration Engine</span>
            <span>Auditable Record Hash: {report.childId}-{report.assessmentDate}</span>
          </div>
        </footer>
      </div>
    </div>
  );
};
