import React, { useState, useMemo } from 'react';
import { Sex, calculateAge, getNormGroupKey, formatNormGroupDisplay } from '../connersConfig';
import { AssessmentRecord } from '../storage';
import { X, Calendar, User, FileText, Check, AlertCircle } from 'lucide-react';

interface NewAssessmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (record: AssessmentRecord) => void;
}

export const NewAssessmentModal: React.FC<NewAssessmentModalProps> = ({
  isOpen,
  onClose,
  onCreate,
}) => {
  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);

  const [childId, setChildId] = useState<string>('');
  const [childName, setChildName] = useState<string>('');
  const [sex, setSex] = useState<Sex>('F');
  const [dateOfBirth, setDateOfBirth] = useState<string>('2016-01-15');
  const [assessmentDate, setAssessmentDate] = useState<string>(todayStr);
  const [grade, setGrade] = useState<string>('');
  const [parentName, setParentName] = useState<string>('');
  const [adminNote, setAdminNote] = useState<string>('');
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  // Compute live age & norm group
  const ageResult = useMemo(() => {
    return calculateAge(dateOfBirth, assessmentDate);
  }, [dateOfBirth, assessmentDate]);

  const normGroupKey = useMemo(() => {
    if (!ageResult.isValid) return '';
    return getNormGroupKey(sex, ageResult.years);
  }, [sex, ageResult]);

  const normGroupDisplay = useMemo(() => {
    if (!normGroupKey) return '';
    return formatNormGroupDisplay(normGroupKey);
  }, [normGroupKey]);

  if (!isOpen) return null;

  const isFormValid =
    childId.trim().length > 0 &&
    ageResult.isValid;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched({ childId: true, dateOfBirth: true, assessmentDate: true });

    if (!isFormValid) return;

    const newRecord: AssessmentRecord = {
      id: `conners-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      childId: childId.trim(),
      childName: childName.trim() || undefined,
      sex,
      dateOfBirth,
      assessmentDate,
      ageYears: ageResult.years,
      ageMonths: ageResult.months,
      normGroupKey,
      grade: grade.trim() || undefined,
      parentName: parentName.trim() || undefined,
      adminNote: adminNote.trim() || undefined,
      status: 'in_progress',
      answers: {},
      openAnswers: {},
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onCreate(newRecord);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="new-assessment-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <span className="text-xs font-semibold tracking-wider text-[#1E5F74] uppercase">
              Counsellor Desk
            </span>
            <h2 id="new-assessment-title" className="text-xl font-serif font-bold text-slate-900">
              Start New Assessment
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Child ID & Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="modal-child-id" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Child ID or Code <span className="text-rose-500">*</span>
              </label>
              <input
                id="modal-child-id"
                type="text"
                required
                value={childId}
                onChange={(e) => setChildId(e.target.value)}
                onBlur={() => setTouched((prev) => ({ ...prev, childId: true }))}
                placeholder="e.g. STU-8491"
                className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
              />
              {touched.childId && !childId.trim() && (
                <p className="text-xs text-rose-600 mt-1">Please enter a child ID or identifier.</p>
              )}
            </div>

            <div>
              <label htmlFor="modal-child-name" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Child Name (Optional)
              </label>
              <input
                id="modal-child-name"
                type="text"
                value={childName}
                onChange={(e) => setChildName(e.target.value)}
                placeholder="e.g. Maya S."
                className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
              />
            </div>
          </div>

          {/* Sex Segmented Control */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Child Sex (For Norm Group) <span className="text-rose-500">*</span>
            </label>
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200/80">
              <button
                type="button"
                onClick={() => setSex('F')}
                className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  sex === 'F'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Female (Girls)
              </button>
              <button
                type="button"
                onClick={() => setSex('M')}
                className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  sex === 'M'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Male (Boys)
              </button>
            </div>
          </div>

          {/* Dates: DOB & Assessment Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="modal-dob" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Date of Birth <span className="text-rose-500">*</span>
              </label>
              <input
                id="modal-dob"
                type="date"
                required
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
              />
            </div>

            <div>
              <label htmlFor="modal-assess-date" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Assessment Date <span className="text-rose-500">*</span>
              </label>
              <input
                id="modal-assess-date"
                type="date"
                required
                value={assessmentDate}
                onChange={(e) => setAssessmentDate(e.target.value)}
                className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
              />
            </div>
          </div>

          {/* Live Age & Norm Group Display Box */}
          <div
            className={`p-3.5 rounded-xl border text-xs space-y-1 ${
              ageResult.isValid
                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}
          >
            {ageResult.isValid ? (
              <>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700">Calculated Exact Age:</span>
                  <span className="font-bold text-slate-900">
                    {ageResult.years} years, {ageResult.months} months
                  </span>
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-emerald-200/60">
                  <span className="font-semibold text-slate-700">Comparison Norm Group:</span>
                  <span className="font-bold text-[#1E5F74]">
                    {normGroupDisplay} ({normGroupKey})
                  </span>
                </div>
              </>
            ) : (
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block">Age Validation Error</span>
                  <span>{ageResult.errorMessage}</span>
                </div>
              </div>
            )}
          </div>

          {/* Optional Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div>
              <label htmlFor="modal-grade" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Grade / Class (Optional)
              </label>
              <input
                id="modal-grade"
                type="text"
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                placeholder="e.g. Grade 5B"
                className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
              />
            </div>

            <div>
              <label htmlFor="modal-parent-name" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Parent / Rater Name (Optional)
              </label>
              <input
                id="modal-parent-name"
                type="text"
                value={parentName}
                onChange={(e) => setParentName(e.target.value)}
                placeholder="e.g. Father, Mother"
                className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
              />
            </div>
          </div>

          <div>
            <label htmlFor="modal-admin-note" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Administration Note (Optional)
            </label>
            <input
              id="modal-admin-note"
              type="text"
              value={adminNote}
              onChange={(e) => setAdminNote(e.target.value)}
              placeholder='e.g. "Read aloud in Marathi", "Self-administered on phone in office"'
              className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E5F74]"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!isFormValid}
              className={`px-5 py-2.5 text-sm font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-2 ${
                isFormValid
                  ? 'bg-[#1E5F74] hover:bg-[#184d5e] text-white cursor-pointer'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>Create assessment</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
