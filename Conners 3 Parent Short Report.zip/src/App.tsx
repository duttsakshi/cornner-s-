/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  loadAssessments,
  saveAssessments,
  saveSingleAssessment,
  deleteAssessment,
  loadNorms,
  saveNorms,
  loadCounsellorSettings,
  saveCounsellorSettings,
  AssessmentRecord,
  CounsellorSettings,
} from './storage';
import { AllNormTables } from './connersConfig';
import { generateAssessmentReport } from './scoringEngine';
import { CounsellorDashboard } from './components/CounsellorDashboard';
import { ClinicianReport } from './components/ClinicianReport';
import { ParentQuestionnaire } from './components/ParentQuestionnaire';
import { NormTablesScreen } from './components/NormTablesScreen';
import { NewAssessmentModal } from './components/NewAssessmentModal';
import { PinModal } from './components/PinModal';
import { AcceptanceTestsModal } from './components/AcceptanceTestsModal';

type AppView =
  | 'dashboard'
  | 'report'
  | 'parent_questionnaire'
  | 'norm_tables';

export default function App() {
  const [assessments, setAssessments] = useState<AssessmentRecord[]>([]);
  const [norms, setNorms] = useState<AllNormTables>({});
  const [settings, setSettings] = useState<CounsellorSettings>(loadCounsellorSettings);
  const [currentView, setCurrentView] = useState<AppView>('dashboard');
  const [activeAssessmentId, setActiveAssessmentId] = useState<string | null>(null);

  // Modal states
  const [isNewAssessmentOpen, setIsNewAssessmentOpen] = useState<boolean>(false);
  const [isPinModalOpen, setIsPinModalOpen] = useState<boolean>(false);
  const [isTestsModalOpen, setIsTestsModalOpen] = useState<boolean>(false);
  const [pinTargetView, setPinTargetView] = useState<AppView>('dashboard');

  // Load persistent records on start
  useEffect(() => {
    const loadedAssessments = loadAssessments();
    const loadedNorms = loadNorms();
    const loadedSettings = loadCounsellorSettings();

    setAssessments(loadedAssessments);
    setNorms(loadedNorms);
    setSettings(loadedSettings);

    // If there is an active sample, preselect it
    if (loadedAssessments.length > 0) {
      setActiveAssessmentId(loadedAssessments[0].id);
    }
  }, []);

  const activeAssessment = assessments.find((a) => a.id === activeAssessmentId) || null;

  // Handle assessment update
  const handleUpdateActiveAssessmentAnswers = (
    answers: Record<number, number>,
    openAnswers: Record<number, string>
  ) => {
    if (!activeAssessment) return;

    const updated: AssessmentRecord = {
      ...activeAssessment,
      answers,
      openAnswers,
      updatedAt: new Date().toISOString(),
    };

    saveSingleAssessment(updated);
    setAssessments((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
  };

  // Complete assessment from parent questionnaire
  const handleCompleteActiveAssessment = () => {
    if (!activeAssessment) return;

    const updated: AssessmentRecord = {
      ...activeAssessment,
      status: 'completed',
      completedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    saveSingleAssessment(updated);
    setAssessments((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
  };

  // Create new assessment
  const handleCreateNewAssessment = (newRecord: AssessmentRecord) => {
    saveSingleAssessment(newRecord);
    setAssessments((prev) => [newRecord, ...prev]);
    setActiveAssessmentId(newRecord.id);
    setIsNewAssessmentOpen(false);

    // Automatically transition to parent questionnaire mode to hand to parent
    setCurrentView('parent_questionnaire');
  };

  // Delete assessment
  const handleDeleteAssessment = (id: string) => {
    deleteAssessment(id);
    setAssessments((prev) => prev.filter((a) => a.id !== id));
    if (activeAssessmentId === id) {
      setActiveAssessmentId(null);
      setCurrentView('dashboard');
    }
  };

  // Save norms
  const handleSaveNorms = (updatedNorms: AllNormTables) => {
    saveNorms(updatedNorms);
    setNorms(updatedNorms);
  };

  // Save settings
  const handleUpdateSettings = (newSettings: CounsellorSettings) => {
    saveCounsellorSettings(newSettings);
    setSettings(newSettings);
  };

  // Pin verification gate
  const requestUnlockView = (target: AppView) => {
    setPinTargetView(target);
    setIsPinModalOpen(true);
  };

  const handlePinSuccess = () => {
    setIsPinModalOpen(false);
    setCurrentView(pinTargetView);
  };

  // Build report model if an assessment is selected
  const activeReport = React.useMemo(() => {
    if (!activeAssessment) return null;
    return generateAssessmentReport(
      activeAssessment.childId,
      activeAssessment.childName || '',
      activeAssessment.sex,
      activeAssessment.dateOfBirth,
      activeAssessment.assessmentDate,
      activeAssessment.ageYears,
      activeAssessment.ageMonths,
      activeAssessment.answers || {},
      activeAssessment.openAnswers || {},
      norms,
      activeAssessment.parentName,
      activeAssessment.grade,
      activeAssessment.adminNote
    );
  }, [activeAssessment, norms]);

  return (
    <div className="min-h-screen bg-[#EEF3F4] text-[#1D2B33] flex flex-col font-sans">
      {/* 1. PARENT QUESTIONNAIRE VIEW (Strict audience isolation: no counsellor headers or scores) */}
      {currentView === 'parent_questionnaire' && activeAssessment && (
        <ParentQuestionnaire
          assessment={activeAssessment}
          onUpdateAnswers={handleUpdateActiveAssessmentAnswers}
          onComplete={handleCompleteActiveAssessment}
          onRequestCounsellorAccess={() => requestUnlockView('report')}
        />
      )}

      {/* 2. CLINICIAN REPORT VIEW */}
      {currentView === 'report' && activeReport && (
        <ClinicianReport
          report={activeReport}
          onBackToDashboard={() => setCurrentView('dashboard')}
          onReturnToParentMode={() => setCurrentView('parent_questionnaire')}
        />
      )}

      {/* 3. NORM TABLES SCREEN */}
      {currentView === 'norm_tables' && (
        <NormTablesScreen
          norms={norms}
          onSaveNorms={handleSaveNorms}
          onBack={() => setCurrentView('dashboard')}
        />
      )}

      {/* 4. COUNSELLOR DASHBOARD */}
      {currentView === 'dashboard' && (
        <CounsellorDashboard
          assessments={assessments}
          onSelectAssessment={(record) => {
            setActiveAssessmentId(record.id);
            setCurrentView('report');
          }}
          onLaunchParentMode={(record) => {
            setActiveAssessmentId(record.id);
            setCurrentView('parent_questionnaire');
          }}
          onOpenNewAssessmentModal={() => setIsNewAssessmentOpen(true)}
          onOpenNormTables={() => setCurrentView('norm_tables')}
          onOpenAcceptanceTests={() => setIsTestsModalOpen(true)}
          onDeleteAssessment={handleDeleteAssessment}
          onLockDashboard={() => {
            if (activeAssessment) {
              setCurrentView('parent_questionnaire');
            } else {
              alert('Please create or select an assessment first.');
            }
          }}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
        />
      )}

      {/* Modals */}
      <NewAssessmentModal
        isOpen={isNewAssessmentOpen}
        onClose={() => setIsNewAssessmentOpen(false)}
        onCreate={handleCreateNewAssessment}
      />

      <PinModal
        isOpen={isPinModalOpen}
        expectedPin={settings.pin}
        onSuccess={handlePinSuccess}
        onCancel={() => setIsPinModalOpen(false)}
        title="Clinician Access Verification"
        description="Please enter the counsellor passcode to access clinical evaluation and report screens."
      />

      <AcceptanceTestsModal
        isOpen={isTestsModalOpen}
        onClose={() => setIsTestsModalOpen(false)}
        norms={norms}
      />
    </div>
  );
}
