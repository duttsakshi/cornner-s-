# Conners 3 Parent Short (Conners 3-P (S)) – Administration and Scoring App

A standalone web application built for school counsellors and clinicians to administer the **Conners 3 Parent Short form** (43 rated items + 2 open-ended questions), calculate scores deterministically, and generate clinical evaluation reports.

---

## Key Features

### 1. Dual Audience Isolation
- **Parent Respondent Mode (Mobile-First)**:
  - Clean, accessible interface designed for mobile phones and tablets.
  - Parents never see scale names, clinical abbreviations, raw scores, T-scores, or validity indicators.
  - Standard administration instructions clearly displayed.
  - Fixed layout with a stable `"Skip for now"` button position across all 43 questions.
  - One-tap `"Submit answers"` option that activates when all questions are answered.
  - Auto-saves responses after every selection.
  - End of questionnaire prompts parent to return the device to the counsellor.
- **Counsellor Clinician Portal**:
  - Passcode-protected access gate.
  - Assessment management dashboard (search, filter, status tracking).
  - New assessment creation with live age calculation and comparison group assignment.
  - Official norm tables editor (0–18 raw score grid across 6 scales, automated validation checks, JSON backup/restore).
  - Built-in deterministic acceptance test runner verifying scoring precision.

### 2. 100% Deterministic Scoring Engine
- **No AI calculations**: All scoring is executed via pure JavaScript using verified norm tables and scoring keys.
- **Validity Checks**: Evaluates Positive Impression (PI) and Negative Impression (NI) scales with cut-offs (Consistent, Possibly Raised, Likely Raised).
- **Exact Age & Norm Grouping**: Calculates completed years and months from date of birth and assessment date. Enforces valid range (6y 0m – 18y 11m) and 24 comparison groups (F-6 to F-17, M-6 to M-17).
- **Standardized Profile Chart**: Monochromatic SVG line chart (40–90 scale, solid 50 baseline, 4 shaded teal bands: Typical, Somewhat higher, Higher than most, Much higher than most).
- **Hedged, Non-Diagnostic Language**: Strictly avoids diagnostic labels (e.g. ADHD, disorder, deficit, at risk, clinically significant), describing results purely in terms of comparisons to norm groups.

### 3. Data Privacy & Compliance
- Compliant with children's mental-health data confidentiality and the **India Digital Personal Data Protection (DPDP) Act 2023**.
- Complete data erasure and local export capabilities.

---

## Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm

### Installation
```bash
# Clone the repository
git clone https://github.com/<your-username>/<your-repo-name>.git

# Navigate into the project directory
cd <your-repo-name>

# Install dependencies
npm install

# Start the local development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Building for Production
```bash
npm run build
```

---

## Project Structure

```
├── src/
│   ├── components/
│   │   ├── AcceptanceTestsModal.tsx   # Scoring verification test suite
│   │   ├── ClinicianReport.tsx        # 9-section clinical report with print stylesheet
│   │   ├── CounsellorDashboard.tsx    # Clinician dashboard & assessment records
│   │   ├── NewAssessmentModal.tsx     # Assessment intake form with live age calculator
│   │   ├── NormTablesScreen.tsx       # 0-18 grid norm table manager & validator
│   │   ├── ParentQuestionnaire.tsx    # Mobile respondent interface
│   │   ├── PinModal.tsx               # Counsellor access security gate
│   │   └── ProfileChart.tsx           # Monochromatic SVG profile chart
│   ├── connersConfig.ts               # Instrument data, items, keys, and norm definitions
│   ├── connersConfig.js               # Re-export configuration module
│   ├── scoringEngine.ts               # Deterministic scoring, validity, and narrative generation
│   ├── storage.ts                     # Local storage persistence and JSON backup
│   ├── App.tsx                        # Application routing and state management
│   ├── index.css                      # Tailwind styling and typography
│   └── main.tsx                       # React application entry point
├── package.json
└── tsconfig.json
```

---

## Disclaimer
These results describe one parent’s ratings over the past month, compared with a normative reference sample. They are not a diagnosis. Results must be interpreted by a qualified professional alongside clinical interview, developmental history, school reports, and direct observation.
