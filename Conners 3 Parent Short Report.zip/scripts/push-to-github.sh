#!/bin/bash
# Helper script to push this repository to GitHub
# Usage: ./scripts/push-to-github.sh <github-username> <repo-name>

if [ -z "$1" ] || [ -z "$2" ]; then
  echo "Usage: ./scripts/push-to-github.sh <github-username> <repo-name>"
  echo "Example: ./scripts/push-to-github.sh duttsakshi19 conners3-parent-short"
  exit 1
fi

USERNAME=$1
REPO=$2

git remote remove origin 2>/dev/null
git remote add origin "https://github.com/${USERNAME}/${REPO}.git"
git branch -M main

echo "Pushing to https://github.com/${USERNAME}/${REPO}.git ..."
git push -u origin main
